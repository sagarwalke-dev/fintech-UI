# Fintech Backend

This is the Spring Boot backend service for the Fintech UI application. It provides RESTful APIs for managing financial data including investments, goals, watchlists, and withdrawals.

## Technologies Used

- Java 11
- Spring Boot 2.7.14
- Maven
- In-memory collections (to be replaced with a database later)

## Project Structure

- `models`: Data models for the application
- `repositories`: Repositories for data access
- `services`: Business logic services
- `controllers`: REST API controllers
- `config`: Configuration classes

## Getting Started

### Prerequisites

- JDK 11 or higher
- Maven 3.6 or higher

### Running the Application

1. Clone the repository
2. Navigate to the project directory
3. Run the following command:

```bash
mvn spring-boot:run
```

The application will start on port 8080.

## API Endpoints

### User APIs
- `GET /api/users`: Get all users
- `GET /api/users/{id}`: Get user by ID
- `POST /api/users`: Create a new user
- `PUT /api/users/{id}`: Update a user
- `DELETE /api/users/{id}`: Delete a user
- `POST /api/users/login`: Authenticate a user
- `PUT /api/users/{id}/safety-net`: Update a user's financial safety net

### Investment APIs
- `GET /api/investments`: Get all investments
- `GET /api/investments/user/{userId}`: Get investments by user ID
- `GET /api/investments/{id}`: Get investment by ID
- `GET /api/investments/user/{userId}/total`: Get total investment value for a user
- `POST /api/investments`: Create a new investment
- `PUT /api/investments/{id}`: Update an investment
- `DELETE /api/investments/{id}`: Delete an investment

### Goal APIs
- `GET /api/goals`: Get all goals
- `GET /api/goals/user/{userId}`: Get goals by user ID
- `GET /api/goals/{id}`: Get goal by ID
- `POST /api/goals`: Create a new goal
- `PUT /api/goals/{id}`: Update a goal
- `PATCH /api/goals/{id}/progress`: Update goal progress
- `DELETE /api/goals/{id}`: Delete a goal

### Watchlist APIs
- `GET /api/watchlist`: Get all watchlist items
- `GET /api/watchlist/user/{userId}`: Get watchlist items by user ID
- `GET /api/watchlist/{id}`: Get watchlist item by ID
- `POST /api/watchlist`: Add an item to the watchlist
- `PUT /api/watchlist/{id}`: Update a watchlist item
- `DELETE /api/watchlist/{id}`: Remove an item from the watchlist
- `POST /api/watchlist/update-prices`: Update prices for all watchlist items

### Withdrawal APIs
- `GET /api/withdrawals`: Get all withdrawals
- `GET /api/withdrawals/user/{userId}`: Get withdrawals by user ID
- `GET /api/withdrawals/investment/{investmentId}`: Get withdrawals by investment ID
- `GET /api/withdrawals/{id}`: Get withdrawal by ID
- `GET /api/withdrawals/user/{userId}/total`: Get total withdrawals for a user
- `POST /api/withdrawals`: Create a new withdrawal
- `DELETE /api/withdrawals/{id}`: Delete a withdrawal

## Future Improvements

- Replace in-memory collections with a database (MySQL, PostgreSQL, etc.)
- Add authentication using JWT or OAuth
- Implement input validation
- Add unit and integration tests
- Create a scheduler for automated price updates
- Add support for transaction history
- Implement file upload for documents/receipts
