package com.fintech.backend.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Goal {
    private String id;
    private String userId;
    private String name;
    private String description;
    private double targetAmount;
    private double currentAmount;
    private LocalDate targetDate;
    private GoalCategory category;
    
    public enum GoalCategory {
        RETIREMENT, HOME, EDUCATION, TRAVEL, EMERGENCY_FUND, OTHER
    }
    
    public Goal(String userId, String name, String description, double targetAmount, 
                LocalDate targetDate, GoalCategory category) {
        this.id = UUID.randomUUID().toString();
        this.userId = userId;
        this.name = name;
        this.description = description;
        this.targetAmount = targetAmount;
        this.currentAmount = 0.0;
        this.targetDate = targetDate;
        this.category = category;
    }
    
    public double getProgressPercentage() {
        if (targetAmount == 0) return 0;
        return (currentAmount / targetAmount) * 100;
    }
}
