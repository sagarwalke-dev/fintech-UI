package com.fintech.backend.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Withdrawal {
    private String id;
    private String userId;
    private String investmentId;
    private double amount;
    private LocalDateTime date;
    private String reason;
    
    public Withdrawal(String userId, String investmentId, double amount, String reason) {
        this.id = UUID.randomUUID().toString();
        this.userId = userId;
        this.investmentId = investmentId;
        this.amount = amount;
        this.date = LocalDateTime.now();
        this.reason = reason;
    }
}
