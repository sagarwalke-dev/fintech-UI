package com.fintech.backend.controllers;

import com.fintech.backend.models.Goal;
import com.fintech.backend.services.GoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/goals")
public class GoalController {
    
    private final GoalService goalService;
    
    @Autowired
    public GoalController(GoalService goalService) {
        this.goalService = goalService;
    }
    
    @GetMapping
    public List<Goal> getAllGoals() {
        return goalService.getAllGoals();
    }
    
    @GetMapping("/user/{userId}")
    public List<Goal> getGoalsByUserId(@PathVariable String userId) {
        return goalService.getGoalsByUserId(userId);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Goal> getGoalById(@PathVariable String id) {
        return goalService.getGoalById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Goal> createGoal(@RequestBody Goal goal) {
        Goal saved = goalService.createGoal(goal);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Goal> updateGoal(@PathVariable String id, @RequestBody Goal goalDetails) {
        return goalService.updateGoal(id, goalDetails)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PatchMapping("/{id}/progress")
    public ResponseEntity<Goal> updateGoalProgress(
            @PathVariable String id, 
            @RequestBody Map<String, Double> request) {
        Double amount = request.get("amount");
        if (amount == null) {
            return ResponseEntity.badRequest().build();
        }
        
        return goalService.updateGoalProgress(id, amount)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGoal(@PathVariable String id) {
        boolean deleted = goalService.deleteGoal(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
