package com.fintech.backend.controllers;

import com.fintech.backend.models.Withdrawal;
import com.fintech.backend.services.WithdrawalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/withdrawals")
public class WithdrawalController {
    
    private final WithdrawalService withdrawalService;
    
    @Autowired
    public WithdrawalController(WithdrawalService withdrawalService) {
        this.withdrawalService = withdrawalService;
    }
    
    @GetMapping
    public List<Withdrawal> getAllWithdrawals() {
        return withdrawalService.getAllWithdrawals();
    }
    
    @GetMapping("/user/{userId}")
    public List<Withdrawal> getWithdrawalsByUserId(@PathVariable String userId) {
        return withdrawalService.getWithdrawalsByUserId(userId);
    }
    
    @GetMapping("/investment/{investmentId}")
    public List<Withdrawal> getWithdrawalsByInvestmentId(@PathVariable String investmentId) {
        return withdrawalService.getWithdrawalsByInvestmentId(investmentId);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Withdrawal> getWithdrawalById(@PathVariable String id) {
        return withdrawalService.getWithdrawalById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/user/{userId}/total")
    public ResponseEntity<Map<String, Double>> getTotalWithdrawals(@PathVariable String userId) {
        double total = withdrawalService.getTotalWithdrawalsForUser(userId);
//        return ResponseEntity.ok(Map.of("total", total));
        return null;
    }
    
    @PostMapping
    public ResponseEntity<Withdrawal> createWithdrawal(@RequestBody Withdrawal withdrawal) {
        return withdrawalService.createWithdrawal(withdrawal)
                .map(saved -> ResponseEntity.status(HttpStatus.CREATED).body(saved))
                .orElse(ResponseEntity.badRequest().build());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWithdrawal(@PathVariable String id) {
        boolean deleted = withdrawalService.deleteWithdrawal(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
