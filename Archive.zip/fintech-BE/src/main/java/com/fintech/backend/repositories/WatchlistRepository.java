package com.fintech.backend.repositories;

import com.fintech.backend.models.WatchlistItem;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Repository
public class WatchlistRepository {
    private final ConcurrentHashMap<String, WatchlistItem> watchlistItems = new ConcurrentHashMap<>();
    
    public List<WatchlistItem> findAll() {
        return new ArrayList<>(watchlistItems.values());
    }
    
    public List<WatchlistItem> findByUserId(String userId) {
        return watchlistItems.values().stream()
                .filter(item -> item.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    public Optional<WatchlistItem> findById(String id) {
        return Optional.ofNullable(watchlistItems.get(id));
    }
    
    public WatchlistItem save(WatchlistItem watchlistItem) {
        watchlistItems.put(watchlistItem.getId(), watchlistItem);
        return watchlistItem;
    }
    
    public void delete(String id) {
        watchlistItems.remove(id);
    }
}
