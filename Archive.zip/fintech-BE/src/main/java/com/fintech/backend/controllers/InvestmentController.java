package com.fintech.backend.controllers;

import com.fintech.backend.models.Investment;
import com.fintech.backend.services.InvestmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/investments")
public class InvestmentController {
    
    private final InvestmentService investmentService;
    
    @Autowired
    public InvestmentController(InvestmentService investmentService) {
        this.investmentService = investmentService;
    }
    
    @GetMapping
    public List<Investment> getAllInvestments() {
        return investmentService.getAllInvestments();
    }
    
    @GetMapping("/user/{userId}")
    public List<Investment> getInvestmentsByUserId(@PathVariable String userId) {
        return investmentService.getInvestmentsByUserId(userId);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Investment> getInvestmentById(@PathVariable String id) {
        return investmentService.getInvestmentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/user/{userId}/total")
    public ResponseEntity<Map<String, Double>> getTotalInvestment(@PathVariable String userId) {
        double total = investmentService.getTotalInvestmentValueForUser(userId);
//        return ResponseEntity.ok(Map.of("total", total));
        return null;
    }
    
    @PostMapping
    public ResponseEntity<Investment> createInvestment(@RequestBody Investment investment) {
        Investment saved = investmentService.createInvestment(investment);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Investment> updateInvestment(
            @PathVariable String id, 
            @RequestBody Investment investmentDetails) {
        return investmentService.updateInvestment(id, investmentDetails)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInvestment(@PathVariable String id) {
        boolean deleted = investmentService.deleteInvestment(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
