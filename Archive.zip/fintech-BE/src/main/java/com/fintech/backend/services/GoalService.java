package com.fintech.backend.services;

import com.fintech.backend.models.Goal;
import com.fintech.backend.repositories.GoalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class GoalService {
    
    private final GoalRepository goalRepository;
    
    @Autowired
    public GoalService(GoalRepository goalRepository) {
        this.goalRepository = goalRepository;
        
        // Add some demo goals if empty
        if (goalRepository.findAll().isEmpty()) {
            // Demo goals for demo user
            Goal demoGoal1 = new Goal(
                    "demo-user-id", 
                    "Retirement", 
                    "Save for retirement by 65", 
                    1000000.0, 
                    LocalDate.now().plusYears(30), 
                    Goal.GoalCategory.RETIREMENT
            );
            demoGoal1.setId("goal-ret-001");
            demoGoal1.setCurrentAmount(150000.0);
            goalRepository.save(demoGoal1);
            
            Goal demoGoal2 = new Goal(
                    "demo-user-id", 
                    "Dream House", 
                    "Save for down payment on a house", 
                    100000.0, 
                    LocalDate.now().plusYears(5), 
                    Goal.GoalCategory.HOME
            );
            demoGoal2.setId("goal-house-001");
            demoGoal2.setCurrentAmount(25000.0);
            goalRepository.save(demoGoal2);
            
            Goal demoGoal3 = new Goal(
                    "demo-user-id", 
                    "World Trip", 
                    "Save for a 6-month world tour", 
                    30000.0, 
                    LocalDate.now().plusYears(2), 
                    Goal.GoalCategory.TRAVEL
            );
            demoGoal3.setId("goal-travel-001");
            demoGoal3.setCurrentAmount(5000.0);
            goalRepository.save(demoGoal3);
            
            // John Doe's goals
            Goal johnGoal1 = new Goal(
                    "user-john-id", 
                    "MBA Degree", 
                    "Save for business school tuition", 
                    80000.0, 
                    LocalDate.now().plusYears(3), 
                    Goal.GoalCategory.EDUCATION
            );
            johnGoal1.setId("goal-edu-001");
            johnGoal1.setCurrentAmount(15000.0);
            goalRepository.save(johnGoal1);
            
            Goal johnGoal2 = new Goal(
                    "user-john-id", 
                    "Emergency Fund", 
                    "Build 6 months of living expenses", 
                    30000.0, 
                    LocalDate.now().plusYears(1), 
                    Goal.GoalCategory.EMERGENCY_FUND
            );
            johnGoal2.setId("goal-emerg-001");
            johnGoal2.setCurrentAmount(12000.0);
            goalRepository.save(johnGoal2);
            
            // Jane Smith's goals
            Goal janeGoal1 = new Goal(
                    "user-jane-id", 
                    "Start a Business", 
                    "Initial capital for a tech startup", 
                    200000.0, 
                    LocalDate.now().plusYears(5), 
                    Goal.GoalCategory.OTHER
            );
            janeGoal1.setId("goal-biz-001");
            janeGoal1.setCurrentAmount(50000.0);
            goalRepository.save(janeGoal1);
            
            Goal janeGoal2 = new Goal(
                    "user-jane-id", 
                    "Beach House", 
                    "Vacation home by the ocean", 
                    350000.0, 
                    LocalDate.now().plusYears(10), 
                    Goal.GoalCategory.HOME
            );
            janeGoal2.setId("goal-beach-001");
            janeGoal2.setCurrentAmount(40000.0);
            goalRepository.save(janeGoal2);
        }
    }
    
    public List<Goal> getAllGoals() {
        return goalRepository.findAll();
    }
    
    public List<Goal> getGoalsByUserId(String userId) {
        return goalRepository.findByUserId(userId);
    }
    
    public Optional<Goal> getGoalById(String id) {
        return goalRepository.findById(id);
    }
    
    public Goal createGoal(Goal goal) {
        return goalRepository.save(goal);
    }
    
    public Optional<Goal> updateGoal(String id, Goal goalDetails) {
        return goalRepository.findById(id)
                .map(existingGoal -> {
                    existingGoal.setName(goalDetails.getName());
                    existingGoal.setDescription(goalDetails.getDescription());
                    existingGoal.setTargetAmount(goalDetails.getTargetAmount());
                    existingGoal.setCurrentAmount(goalDetails.getCurrentAmount());
                    existingGoal.setTargetDate(goalDetails.getTargetDate());
                    existingGoal.setCategory(goalDetails.getCategory());
                    return goalRepository.save(existingGoal);
                });
    }
    
    public Optional<Goal> updateGoalProgress(String id, double contributionAmount) {
        return goalRepository.findById(id)
                .map(existingGoal -> {
                    double newAmount = existingGoal.getCurrentAmount() + contributionAmount;
                    existingGoal.setCurrentAmount(newAmount);
                    return goalRepository.save(existingGoal);
                });
    }
    
    public boolean deleteGoal(String id) {
        Optional<Goal> goal = goalRepository.findById(id);
        if (goal.isPresent()) {
            goalRepository.delete(id);
            return true;
        }
        return false;
    }
}
