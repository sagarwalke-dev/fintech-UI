package com.fintech.backend.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WatchlistItem {
    private String id;
    private String userId;
    private String assetName;
    private String assetSymbol;
    private double currentPrice;
    private LocalDateTime addedDate;
    private AssetType type;
    
    public enum AssetType {
        STOCK, BOND, CRYPTO, ETF, MUTUAL_FUND, OTHER
    }
    
    public WatchlistItem(String userId, String assetName, String assetSymbol, double currentPrice, AssetType type) {
        this.id = UUID.randomUUID().toString();
        this.userId = userId;
        this.assetName = assetName;
        this.assetSymbol = assetSymbol;
        this.currentPrice = currentPrice;
        this.addedDate = LocalDateTime.now();
        this.type = type;
    }
}
