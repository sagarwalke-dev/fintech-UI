package com.fintech.backend.services;

import com.fintech.backend.models.WatchlistItem;
import com.fintech.backend.repositories.WatchlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class WatchlistService {
    
    private final WatchlistRepository watchlistRepository;
    
    @Autowired
    public WatchlistService(WatchlistRepository watchlistRepository) {
        this.watchlistRepository = watchlistRepository;
        
        // Add some demo watchlist items if empty
        if (watchlistRepository.findAll().isEmpty()) {
            // Demo watchlist items for demo user
            WatchlistItem demoItem1 = new WatchlistItem(
                    "demo-user-id", 
                    "Microsoft Corporation", 
                    "MSFT", 
                    380.0, 
                    WatchlistItem.AssetType.STOCK
            );
            demoItem1.setId("watch-msft-001");
            demoItem1.setAddedDate(LocalDateTime.now().minusDays(30));
            watchlistRepository.save(demoItem1);
            
            WatchlistItem demoItem2 = new WatchlistItem(
                    "demo-user-id", 
                    "Ethereum", 
                    "ETH", 
                    3200.0, 
                    WatchlistItem.AssetType.CRYPTO
            );
            demoItem2.setId("watch-eth-001");
            demoItem2.setAddedDate(LocalDateTime.now().minusDays(15));
            watchlistRepository.save(demoItem2);
            
            WatchlistItem demoItem3 = new WatchlistItem(
                    "demo-user-id", 
                    "Vanguard Total Stock Market ETF", 
                    "VTI", 
                    250.0, 
                    WatchlistItem.AssetType.ETF
            );
            demoItem3.setId("watch-vti-001");
            demoItem3.setAddedDate(LocalDateTime.now().minusDays(5));
            watchlistRepository.save(demoItem3);
            
            WatchlistItem demoItem4 = new WatchlistItem(
                    "demo-user-id", 
                    "Alphabet Inc.", 
                    "GOOGL", 
                    155.0, 
                    WatchlistItem.AssetType.STOCK
            );
            demoItem4.setId("watch-googl-001");
            demoItem4.setAddedDate(LocalDateTime.now().minusDays(10));
            watchlistRepository.save(demoItem4);
            
            // John Doe's watchlist items
            WatchlistItem johnItem1 = new WatchlistItem(
                    "user-john-id", 
                    "Amazon.com, Inc.", 
                    "AMZN", 
                    180.0, 
                    WatchlistItem.AssetType.STOCK
            );
            johnItem1.setId("watch-amzn-001");
            johnItem1.setAddedDate(LocalDateTime.now().minusDays(20));
            watchlistRepository.save(johnItem1);
            
            WatchlistItem johnItem2 = new WatchlistItem(
                    "user-john-id", 
                    "Solana", 
                    "SOL", 
                    140.0, 
                    WatchlistItem.AssetType.CRYPTO
            );
            johnItem2.setId("watch-sol-001");
            johnItem2.setAddedDate(LocalDateTime.now().minusDays(8));
            watchlistRepository.save(johnItem2);
            
            // Jane Smith's watchlist items
            WatchlistItem janeItem1 = new WatchlistItem(
                    "user-jane-id", 
                    "NVIDIA Corporation", 
                    "NVDA", 
                    950.0, 
                    WatchlistItem.AssetType.STOCK
            );
            janeItem1.setId("watch-nvda-001");
            janeItem1.setAddedDate(LocalDateTime.now().minusDays(25));
            watchlistRepository.save(janeItem1);
            
            WatchlistItem janeItem2 = new WatchlistItem(
                    "user-jane-id", 
                    "iShares MSCI Emerging Markets ETF", 
                    "EEM", 
                    42.0, 
                    WatchlistItem.AssetType.ETF
            );
            janeItem2.setId("watch-eem-001");
            janeItem2.setAddedDate(LocalDateTime.now().minusDays(12));
            watchlistRepository.save(janeItem2);
        }
    }
    
    public List<WatchlistItem> getAllWatchlistItems() {
        return watchlistRepository.findAll();
    }
    
    public List<WatchlistItem> getWatchlistItemsByUserId(String userId) {
        return watchlistRepository.findByUserId(userId);
    }
    
    public Optional<WatchlistItem> getWatchlistItemById(String id) {
        return watchlistRepository.findById(id);
    }
    
    public WatchlistItem createWatchlistItem(WatchlistItem watchlistItem) {
        return watchlistRepository.save(watchlistItem);
    }
    
    public Optional<WatchlistItem> updateWatchlistItem(String id, WatchlistItem itemDetails) {
        return watchlistRepository.findById(id)
                .map(existingItem -> {
                    existingItem.setAssetName(itemDetails.getAssetName());
                    existingItem.setAssetSymbol(itemDetails.getAssetSymbol());
                    existingItem.setCurrentPrice(itemDetails.getCurrentPrice());
                    existingItem.setType(itemDetails.getType());
                    return watchlistRepository.save(existingItem);
                });
    }
    
    public boolean deleteWatchlistItem(String id) {
        Optional<WatchlistItem> item = watchlistRepository.findById(id);
        if (item.isPresent()) {
            watchlistRepository.delete(id);
            return true;
        }
        return false;
    }
    
    // This would typically call an external API to update prices
    // For now, we'll simulate price updates with random fluctuations
    public void updateWatchlistPrices() {
        List<WatchlistItem> items = watchlistRepository.findAll();
        for (WatchlistItem item : items) {
            double priceChange = (Math.random() * 0.06) - 0.03; // -3% to +3% change
            double newPrice = item.getCurrentPrice() * (1 + priceChange);
            item.setCurrentPrice(Math.round(newPrice * 100.0) / 100.0); // Round to 2 decimals
            watchlistRepository.save(item);
        }
    }
}
