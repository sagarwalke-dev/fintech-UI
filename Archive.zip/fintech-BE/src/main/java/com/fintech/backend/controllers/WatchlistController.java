package com.fintech.backend.controllers;

import com.fintech.backend.models.WatchlistItem;
import com.fintech.backend.services.WatchlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/watchlist")
public class WatchlistController {
    
    private final WatchlistService watchlistService;
    
    @Autowired
    public WatchlistController(WatchlistService watchlistService) {
        this.watchlistService = watchlistService;
    }
    
    @GetMapping
    public List<WatchlistItem> getAllWatchlistItems() {
        return watchlistService.getAllWatchlistItems();
    }
    
    @GetMapping("/user/{userId}")
    public List<WatchlistItem> getWatchlistItemsByUserId(@PathVariable String userId) {
        return watchlistService.getWatchlistItemsByUserId(userId);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<WatchlistItem> getWatchlistItemById(@PathVariable String id) {
        return watchlistService.getWatchlistItemById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<WatchlistItem> createWatchlistItem(@RequestBody WatchlistItem watchlistItem) {
        WatchlistItem saved = watchlistService.createWatchlistItem(watchlistItem);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<WatchlistItem> updateWatchlistItem(
            @PathVariable String id, 
            @RequestBody WatchlistItem itemDetails) {
        return watchlistService.updateWatchlistItem(id, itemDetails)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWatchlistItem(@PathVariable String id) {
        boolean deleted = watchlistService.deleteWatchlistItem(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/update-prices")
    public ResponseEntity<Void> updateWatchlistPrices() {
        watchlistService.updateWatchlistPrices();
        return ResponseEntity.ok().build();
    }
}
