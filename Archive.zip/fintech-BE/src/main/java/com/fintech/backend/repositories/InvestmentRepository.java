package com.fintech.backend.repositories;

import com.fintech.backend.models.Investment;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Repository
public class InvestmentRepository {
    private final ConcurrentHashMap<String, Investment> investments = new ConcurrentHashMap<>();
    
    public List<Investment> findAll() {
        return new ArrayList<>(investments.values());
    }
    
    public List<Investment> findByUserId(String userId) {
        return investments.values().stream()
                .filter(investment -> investment.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    public Optional<Investment> findById(String id) {
        return Optional.ofNullable(investments.get(id));
    }
    
    public Investment save(Investment investment) {
        if (investment.getId() == null) {
            investment.setId(java.util.UUID.randomUUID().toString());
        }
        investments.put(investment.getId(), investment);
        return investment;
    }
    
    public void delete(String id) {
        investments.remove(id);
    }
}
