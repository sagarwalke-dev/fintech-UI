package com.fintech.backend.repositories;

import com.fintech.backend.models.Withdrawal;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Repository
public class WithdrawalRepository {
    private final ConcurrentHashMap<String, Withdrawal> withdrawals = new ConcurrentHashMap<>();
    
    public List<Withdrawal> findAll() {
        return new ArrayList<>(withdrawals.values());
    }
    
    public List<Withdrawal> findByUserId(String userId) {
        return withdrawals.values().stream()
                .filter(withdrawal -> withdrawal.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    public List<Withdrawal> findByInvestmentId(String investmentId) {
        return withdrawals.values().stream()
                .filter(withdrawal -> withdrawal.getInvestmentId().equals(investmentId))
                .collect(Collectors.toList());
    }
    
    public Optional<Withdrawal> findById(String id) {
        return Optional.ofNullable(withdrawals.get(id));
    }
    
    public Withdrawal save(Withdrawal withdrawal) {
        withdrawals.put(withdrawal.getId(), withdrawal);
        return withdrawal;
    }
    
    public void delete(String id) {
        withdrawals.remove(id);
    }
}
