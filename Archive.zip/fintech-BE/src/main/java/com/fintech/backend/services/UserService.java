package com.fintech.backend.services;

import com.fintech.backend.models.User;
import com.fintech.backend.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    
    private final UserRepository userRepository;
    
    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
        
        // Add some demo users
        if (userRepository.findAll().isEmpty()) {
            // Demo User with specific ID
            User demoUser = new User("demo", "demo@example.com", "password", "Demo", "User");
            demoUser.setId("demo-user-id"); // Setting a fixed ID to reference in other services
            demoUser.setFinancialSafetyNet(15000.0);
            userRepository.save(demoUser);
            
            // John Doe user
            User johnDoe = new User("johndoe", "john@example.com", "password", "John", "Doe");
            johnDoe.setId("user-john-id");
            johnDoe.setFinancialSafetyNet(8500.0);
            userRepository.save(johnDoe);
            
            // Jane Smith user
            User janeSmith = new User("janesmith", "jane@example.com", "password", "Jane", "Smith");
            janeSmith.setId("user-jane-id");
            janeSmith.setFinancialSafetyNet(12000.0);
            userRepository.save(janeSmith);
        }
    }
    
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    public Optional<User> getUserById(String id) {
        return userRepository.findById(id);
    }
    
    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    public User createUser(User user) {
        return userRepository.save(user);
    }
    
    public Optional<User> updateUser(String id, User userDetails) {
        return userRepository.findById(id)
                .map(existingUser -> {
                    existingUser.setFirstName(userDetails.getFirstName());
                    existingUser.setLastName(userDetails.getLastName());
                    existingUser.setEmail(userDetails.getEmail());
                    existingUser.setFinancialSafetyNet(userDetails.getFinancialSafetyNet());
                    return userRepository.save(existingUser);
                });
    }
    
    public void deleteUser(String id) {
        userRepository.delete(id);
    }
    
    public Optional<User> authenticateUser(String username, String password) {
        return userRepository.findByUsername(username)
                .filter(user -> user.getPassword().equals(password));
    }
    
    public Optional<User> updateFinancialSafetyNet(String id, double amount) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setFinancialSafetyNet(amount);
                    return userRepository.save(user);
                });
    }
}
