package com.fintech.backend.services;

import com.fintech.backend.models.Investment;
import com.fintech.backend.models.Withdrawal;
import com.fintech.backend.repositories.InvestmentRepository;
import com.fintech.backend.repositories.WithdrawalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WithdrawalService {
    
    private final WithdrawalRepository withdrawalRepository;
    private final InvestmentRepository investmentRepository;
    
    @Autowired
    public WithdrawalService(WithdrawalRepository withdrawalRepository, InvestmentRepository investmentRepository) {
        this.withdrawalRepository = withdrawalRepository;
        this.investmentRepository = investmentRepository;
        
        // Add some demo withdrawals if repository is empty
        if (withdrawalRepository.findAll().isEmpty()) {
            // Demo user withdrawals
            Withdrawal demoWithdrawal1 = new Withdrawal(
                    "demo-user-id",
                    "inv-aapl-001",
                    500.0,
                    "Emergency expense"
            );
            demoWithdrawal1.setId("with-001");
            demoWithdrawal1.setDate(java.time.LocalDateTime.now().minusWeeks(2));
            withdrawalRepository.save(demoWithdrawal1);
            
            Withdrawal demoWithdrawal2 = new Withdrawal(
                    "demo-user-id",
                    "inv-btc-001",
                    200.0,
                    "Car repair"
            );
            demoWithdrawal2.setId("with-002");
            demoWithdrawal2.setDate(java.time.LocalDateTime.now().minusDays(10));
            withdrawalRepository.save(demoWithdrawal2);
            
            // John Doe's withdrawals
            Withdrawal johnWithdrawal = new Withdrawal(
                    "user-john-id",
                    "inv-msft-001",
                    1000.0,
                    "Home renovation"
            );
            johnWithdrawal.setId("with-003");
            johnWithdrawal.setDate(java.time.LocalDateTime.now().minusMonths(1));
            withdrawalRepository.save(johnWithdrawal);
            
            // Jane Smith's withdrawals
            Withdrawal janeWithdrawal = new Withdrawal(
                    "user-jane-id",
                    "inv-tsla-001",
                    750.0,
                    "Vacation expenses"
            );
            janeWithdrawal.setId("with-004");
            janeWithdrawal.setDate(java.time.LocalDateTime.now().minusWeeks(3));
            withdrawalRepository.save(janeWithdrawal);
        }
    }
    
    public List<Withdrawal> getAllWithdrawals() {
        return withdrawalRepository.findAll();
    }
    
    public List<Withdrawal> getWithdrawalsByUserId(String userId) {
        return withdrawalRepository.findByUserId(userId);
    }
    
    public List<Withdrawal> getWithdrawalsByInvestmentId(String investmentId) {
        return withdrawalRepository.findByInvestmentId(investmentId);
    }
    
    public Optional<Withdrawal> getWithdrawalById(String id) {
        return withdrawalRepository.findById(id);
    }
    
    public Optional<Withdrawal> createWithdrawal(Withdrawal withdrawal) {
        Optional<Investment> investmentOpt = investmentRepository.findById(withdrawal.getInvestmentId());
        
        if (investmentOpt.isPresent()) {
            Investment investment = investmentOpt.get();
            if (investment.getAmount() >= withdrawal.getAmount()) {
                // Update investment amount
                investment.setAmount(investment.getAmount() - withdrawal.getAmount());
                investmentRepository.save(investment);
                
                // Save and return withdrawal
                return Optional.of(withdrawalRepository.save(withdrawal));
            }
        }
        
        return Optional.empty();
    }
    
    public boolean deleteWithdrawal(String id) {
        Optional<Withdrawal> withdrawal = withdrawalRepository.findById(id);
        if (withdrawal.isPresent()) {
            withdrawalRepository.delete(id);
            return true;
        }
        return false;
    }
    
    public double getTotalWithdrawalsForUser(String userId) {
        return withdrawalRepository.findByUserId(userId)
                .stream()
                .mapToDouble(Withdrawal::getAmount)
                .sum();
    }
}
