package com.fintech.backend.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Investment {
    private String id;
    private String userId;
    private String assetName;
    private String assetSymbol;
    private double amount;
    private double quantity;
    private double priceAtPurchase;
    private LocalDateTime purchaseDate;
    private InvestmentType type;
    
    public enum InvestmentType {
        STOCK, BOND, CRYPTO, ETF, MUTUAL_FUND, OTHER
    }
    
    public Investment(String userId, String assetName, String assetSymbol, double amount, 
                      double quantity, double priceAtPurchase, InvestmentType type) {
        this.id = UUID.randomUUID().toString();
        this.userId = userId;
        this.assetName = assetName;
        this.assetSymbol = assetSymbol;
        this.amount = amount;
        this.quantity = quantity;
        this.priceAtPurchase = priceAtPurchase;
        this.purchaseDate = LocalDateTime.now();
        this.type = type;
    }
}
