package com.fintech.backend.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private String id;
    private String username;
    private String email;
    private String password; // In a real app, this would be hashed
    private String firstName;
    private String lastName;
    private double financialSafetyNet; // Emergency fund amount
    private List<Investment> investments;
    private List<Goal> goals;

    public User(String username, String email, String password, String firstName, String lastName) {
        this.id = UUID.randomUUID().toString();
        this.username = username;
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.financialSafetyNet = 0.0;
        this.investments = new ArrayList<>();
        this.goals = new ArrayList<>();
    }
}
