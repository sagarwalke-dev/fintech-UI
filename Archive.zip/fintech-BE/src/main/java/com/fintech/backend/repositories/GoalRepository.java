package com.fintech.backend.repositories;

import com.fintech.backend.models.Goal;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Repository
public class GoalRepository {
    private final ConcurrentHashMap<String, Goal> goals = new ConcurrentHashMap<>();
    
    public List<Goal> findAll() {
        return new ArrayList<>(goals.values());
    }
    
    public List<Goal> findByUserId(String userId) {
        return goals.values().stream()
                .filter(goal -> goal.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    public Optional<Goal> findById(String id) {
        return Optional.ofNullable(goals.get(id));
    }
    
    public Goal save(Goal goal) {
        if (goal.getId() == null) {
            goal.setId(java.util.UUID.randomUUID().toString());
        }
        goals.put(goal.getId(), goal);
        return goal;
    }
    
    public void delete(String id) {
        goals.remove(id);
    }
}
