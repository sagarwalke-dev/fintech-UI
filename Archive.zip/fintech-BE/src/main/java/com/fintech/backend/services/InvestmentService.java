package com.fintech.backend.services;

import com.fintech.backend.models.Investment;
import com.fintech.backend.repositories.InvestmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class InvestmentService {
    
    private final InvestmentRepository investmentRepository;
    
    @Autowired
    public InvestmentService(InvestmentRepository investmentRepository) {
        this.investmentRepository = investmentRepository;
        
        // Add some demo investments if empty
        if (investmentRepository.findAll().isEmpty()) {
            // Demo investments for demo user
            Investment demoInvestment1 = new Investment(
                    "demo-user-id", 
                    "Apple Inc.", 
                    "AAPL", 
                    5000.0, 
                    10.0, 
                    500.0, 
                    Investment.InvestmentType.STOCK
            );
            demoInvestment1.setId("inv-aapl-001");
            demoInvestment1.setPurchaseDate(LocalDateTime.now().minusMonths(6));
            investmentRepository.save(demoInvestment1);
            
            Investment demoInvestment2 = new Investment(
                    "demo-user-id", 
                    "Bitcoin", 
                    "BTC", 
                    2000.0, 
                    0.05, 
                    40000.0, 
                    Investment.InvestmentType.CRYPTO
            );
            demoInvestment2.setId("inv-btc-001");
            demoInvestment2.setPurchaseDate(LocalDateTime.now().minusMonths(3));
            investmentRepository.save(demoInvestment2);
            
            Investment demoInvestment3 = new Investment(
                    "demo-user-id", 
                    "S&P 500 ETF", 
                    "SPY", 
                    10000.0, 
                    20.0, 
                    500.0, 
                    Investment.InvestmentType.ETF
            );
            demoInvestment3.setId("inv-spy-001");
            demoInvestment3.setPurchaseDate(LocalDateTime.now().minusMonths(12));
            investmentRepository.save(demoInvestment3);
            
            // John Doe's investments
            Investment johnInvestment1 = new Investment(
                    "user-john-id", 
                    "Microsoft Corporation", 
                    "MSFT", 
                    7500.0, 
                    25.0, 
                    300.0, 
                    Investment.InvestmentType.STOCK
            );
            johnInvestment1.setId("inv-msft-001");
            johnInvestment1.setPurchaseDate(LocalDateTime.now().minusMonths(8));
            investmentRepository.save(johnInvestment1);
            
            Investment johnInvestment2 = new Investment(
                    "user-john-id", 
                    "Ethereum", 
                    "ETH", 
                    3000.0, 
                    1.5, 
                    2000.0, 
                    Investment.InvestmentType.CRYPTO
            );
            johnInvestment2.setId("inv-eth-001");
            johnInvestment2.setPurchaseDate(LocalDateTime.now().minusMonths(5));
            investmentRepository.save(johnInvestment2);
            
            // Jane Smith's investments
            Investment janeInvestment1 = new Investment(
                    "user-jane-id", 
                    "Tesla Inc.", 
                    "TSLA", 
                    6000.0, 
                    8.0, 
                    750.0, 
                    Investment.InvestmentType.STOCK
            );
            janeInvestment1.setId("inv-tsla-001");
            janeInvestment1.setPurchaseDate(LocalDateTime.now().minusMonths(10));
            investmentRepository.save(janeInvestment1);
            
            Investment janeInvestment2 = new Investment(
                    "user-jane-id", 
                    "Bond ETF", 
                    "BND", 
                    15000.0, 
                    150.0, 
                    100.0, 
                    Investment.InvestmentType.BOND
            );
            janeInvestment2.setId("inv-bnd-001");
            janeInvestment2.setPurchaseDate(LocalDateTime.now().minusMonths(18));
            investmentRepository.save(janeInvestment2);
        }
    }
    
    public List<Investment> getAllInvestments() {
        return investmentRepository.findAll();
    }
    
    public List<Investment> getInvestmentsByUserId(String userId) {
        return investmentRepository.findByUserId(userId);
    }
    
    public Optional<Investment> getInvestmentById(String id) {
        return investmentRepository.findById(id);
    }
    
    public Investment createInvestment(Investment investment) {
        return investmentRepository.save(investment);
    }
    
    public Optional<Investment> updateInvestment(String id, Investment investmentDetails) {
        return investmentRepository.findById(id)
                .map(existingInvestment -> {
                    existingInvestment.setAssetName(investmentDetails.getAssetName());
                    existingInvestment.setAssetSymbol(investmentDetails.getAssetSymbol());
                    existingInvestment.setAmount(investmentDetails.getAmount());
                    existingInvestment.setQuantity(investmentDetails.getQuantity());
                    existingInvestment.setPriceAtPurchase(investmentDetails.getPriceAtPurchase());
                    existingInvestment.setType(investmentDetails.getType());
                    return investmentRepository.save(existingInvestment);
                });
    }
    
    public boolean deleteInvestment(String id) {
        Optional<Investment> investment = investmentRepository.findById(id);
        if (investment.isPresent()) {
            investmentRepository.delete(id);
            return true;
        }
        return false;
    }
    
    public double getTotalInvestmentValueForUser(String userId) {
        return investmentRepository.findByUserId(userId)
                .stream()
                .mapToDouble(Investment::getAmount)
                .sum();
    }
}
