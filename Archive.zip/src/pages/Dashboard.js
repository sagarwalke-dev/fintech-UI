import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Card, 
  CardContent, 
  Typography, 
  Grid, 
  Chip, 
  Avatar, 
  Stack, 
  LinearProgress,
  IconButton,
  Button,
  CircularProgress,
  Alert,
  Snackbar
} from '@mui/material';
import { styled } from '@mui/system';
import { Line } from 'react-chartjs-2';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import { useNavigate } from 'react-router-dom';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import AddIcon from '@mui/icons-material/Add';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import ShieldIcon from '@mui/icons-material/Shield';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';
import AddInvestmentModal from '../components/AddInvestmentModal';
import AddWithdrawalModal from '../components/AddWithdrawalModal';
import AddGoalModal from '../components/AddGoalModal';
import GoalDetailsModal from '../components/GoalDetailsModal';
import FinancialSafetyNetModal from '../components/FinancialSafetyNetModal';
import { API } from '../utils/api';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

// Styled components
const GradientCard = styled(Card)(({ theme }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
  color: '#fff',
  overflow: 'hidden',
  position: 'relative',
}));

const AssetCard = styled(Card)(({ theme }) => ({
  transition: 'transform 0.2s',
  '&:hover': {
    transform: 'translateY(-5px)',
  },
}));

const PerformanceChip = styled(Chip)(({ gain, theme }) => ({
  backgroundColor: gain ? 'rgba(0, 192, 135, 0.15)' : 'rgba(255, 87, 87, 0.15)',
  color: gain ? '#00C087' : '#FF5757',
}));

// Mock data
const portfolioValue = {
  current: 127689.45,
  change: 2458.23,
  changePercent: 1.96,
  history: [112000, 116000, 114000, 119000, 122000, 125000, 127600]
};

// Portfolio data matching the Explore page
const portfolioData = [
  {
    name: 'Stocks',
    value: 185000,
    change: 3.2,
    color: '#5367FF',
    icon: '📈',
  },
  {
    name: 'Mutual Funds',
    value: 120000,
    change: 1.8,
    color: '#00C087',
    icon: '📊',
  },
  {
    name: 'Fixed Deposits',
    value: 75000,
    change: 0.5,
    color: '#FF5757',
    icon: '🏦',
  },
  {
    name: 'Cryptocurrency',
    value: 45000,
    change: -2.1,
    color: '#FFB800',
    icon: '₿',
  }
];

const assetAllocation = [
  { type: 'Stocks', value: 62.5, color: '#5367FF' },
  { type: 'Mutual Funds', value: 25.3, color: '#00C087' },
  { type: 'Crypto', value: 8.7, color: '#FF9800' },
  { type: 'Cash', value: 3.5, color: '#E0E0E0' }
];

const topInvestments = [
  { name: 'Apple Inc.', symbol: 'AAPL', price: 182.63, change: 1.25, icon: '🍏' },
  { name: 'Microsoft Corp.', symbol: 'MSFT', price: 337.18, change: -0.78, icon: '🪟' },
  { name: 'Amazon.com Inc.', symbol: 'AMZN', price: 145.22, change: 2.10, icon: '📦' },
  { name: 'Bitcoin', symbol: 'BTC', price: 59325.45, change: 5.32, icon: '₿' }
];

// Mock data for financial safety net
const financialSafetyNetData = {
  emergencyFund: {
    value: 500000,
    target: 600000,
    progress: 83,
    icon: '🚨',
    color: '#00C087'
  },
  healthInsurance: {
    value: 1000000,
    provider: 'Star Health Insurance',
    renewalDate: '2026-03-15',
    icon: '⚕️',
    color: '#5367FF'
  },
  lifeInsurance: {
    value: 5000000,
    provider: 'HDFC Life Insurance',
    renewalDate: '2026-05-22',
    icon: '🛡️',
    color: '#FFB800'
  },
  epf: {
    value: 850000,
    uanNumber: '100021022345',
    icon: '🏦',
    color: '#5367FF'
  },
  otherSavings: {
    type: 'Fixed Deposit',
    value: 200000,
    icon: '💰',
    color: '#FF9800'
  }
};

// Mock data for financial goals
const financialGoalsData = [
  {
    name: 'Home Down Payment',
    value: 800000,
    target: 2000000,
    progress: 40,
    color: '#FF9800',
    icon: '🏠',
    priority: 'High',
    priorityColor: '#FF5757',
    date: 'Aug 15, 2026',
    monthly: 25000
  },
  {
    name: 'Retirement',
    value: 1250000,
    target: 5000000,
    progress: 25,
    color: '#5367FF',
    icon: '👴',
    priority: 'Medium',
    priorityColor: '#FF9800',
    date: 'Mar 10, 2045',
    monthly: 15000
  },
  {
    name: 'Emergency Fund',
    value: 475000,
    target: 500000,
    progress: 95,
    color: '#00C087',
    icon: '🚨',
    priority: 'High',
    priorityColor: '#FF5757',
    date: 'Dec 31, 2023',
    monthly: 10000
  },
  {
    name: 'Travel Fund',
    value: 120000,
    target: 300000,
    progress: 40,
    color: '#5367FF',
    icon: '✈️',
    priority: 'Low',
    priorityColor: '#00C087',
    date: 'Jun 30, 2026',
    monthly: 8000
  },
  {
    name: 'Education Fund',
    value: 360000,
    target: 600000,
    progress: 60,
    color: '#FF9800',
    icon: '🎓',
    priority: 'Medium',
    priorityColor: '#FF9800',
    date: 'Sep 01, 2030',
    monthly: 12000
  }
];

// Chart options
const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false,
    },
    tooltip: {
      mode: 'index',
      intersect: false,
    },
  },
  elements: {
    line: {
      tension: 0.4,
      borderWidth: 2,
    },
    point: {
      radius: 0,
    },
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
      display: false,
    },
    y: {
      grid: {
        display: false,
      },
      display: false,
    },
  },
};

const chartData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
  datasets: [
    {
      data: portfolioValue.history,
      borderColor: '#FFFFFF',
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      fill: true,
    },
  ],
};

const Dashboard = () => {
  const [isAmountHidden, setIsAmountHidden] = useState(false);
  const [isInvestmentModalOpen, setIsInvestmentModalOpen] = useState(false);
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [isSafetyNetModalOpen, setIsSafetyNetModalOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState(null);
  const [isGoalDetailsModalOpen, setIsGoalDetailsModalOpen] = useState(false);
  const [safetyNetData, setSafetyNetData] = useState(financialSafetyNetData);
  const navigate = useNavigate();
  
  // API data state
  const [apiPortfolioData, setApiPortfolioData] = useState(null);
  const [holdings, setHoldings] = useState([]);
  const [goals, setGoals] = useState([]); // Initialize as empty array to prevent null
  const [loading, setLoading] = useState({
    portfolio: true,
    holdings: true,
    goals: true
  });
  const [error, setError] = useState({
    portfolio: null,
    holdings: null,
    goals: null
  });
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'info'
  });
  
  // Fetch portfolio data from API
  useEffect(() => {
    const fetchPortfolio = async () => {
      try {
        setLoading(prev => ({ ...prev, portfolio: true }));
        const data = await API.getPortfolio();
        setApiPortfolioData(data);
        setLoading(prev => ({ ...prev, portfolio: false }));
      } catch (err) {
        console.error('Error fetching portfolio:', err);
        setError(prev => ({ ...prev, portfolio: 'Failed to load portfolio data' }));
        setLoading(prev => ({ ...prev, portfolio: false }));
      }
    };

    fetchPortfolio();
  }, []);

  // Fetch holdings data from API
  useEffect(() => {
    const fetchHoldings = async () => {
      try {
        setLoading(prev => ({ ...prev, holdings: true }));
        const data = await API.getHoldings();
        setHoldings(data);
        setLoading(prev => ({ ...prev, holdings: false }));
      } catch (err) {
        console.error('Error fetching holdings:', err);
        setError(prev => ({ ...prev, holdings: 'Failed to load holdings data' }));
        setLoading(prev => ({ ...prev, holdings: false }));
      }
    };

    fetchHoldings();
  }, []);

  // Fetch goals data from API
  useEffect(() => {
    const fetchGoals = async () => {
      try {
        setLoading(prev => ({ ...prev, goals: true }));
        const data = await API.getGoals();
        // Ensure we don't set goals to null or undefined
        setGoals(data || []);
        setLoading(prev => ({ ...prev, goals: false }));
      } catch (err) {
        console.error('Error fetching goals:', err);
        setError(prev => ({ ...prev, goals: 'Failed to load goals data' }));
        setLoading(prev => ({ ...prev, goals: false }));
      }
    };

    fetchGoals();
  }, []);



  const toggleAmountVisibility = () => {
    setIsAmountHidden(!isAmountHidden);
  };
  
  const handleOpenInvestmentModal = () => {
    setIsInvestmentModalOpen(true);
  };
  
  const handleCloseInvestmentModal = () => {
    setIsInvestmentModalOpen(false);
  };

  const handleOpenWithdrawalModal = () => {
    setIsWithdrawalModalOpen(true);
  };
  
  const handleCloseWithdrawalModal = () => {
    setIsWithdrawalModalOpen(false);
  };

  const handleOpenGoalModal = () => {
    setIsGoalModalOpen(true);
  };
  
  const handleCloseGoalModal = () => {
    setIsGoalModalOpen(false);
  };
  
  // Handle goals update from AddGoalModal
  const handleGoalsUpdate = (updatedGoals) => {
    setGoals(updatedGoals || []);
  };

  const handleOpenSafetyNetModal = () => {
    setIsSafetyNetModalOpen(true);
  };
  
  const handleCloseSafetyNetModal = () => {
    setIsSafetyNetModalOpen(false);
  };

  const handleSaveSafetyNet = (data) => {
    // In a real application, this would update the data in the backend
    // For now, we just update the local state
    const updatedSafetyNetData = {
      emergencyFund: {
        ...safetyNetData.emergencyFund,
        value: parseFloat(data.emergencyFund) || safetyNetData.emergencyFund.value,
      },
      healthInsurance: {
        ...safetyNetData.healthInsurance,
        value: parseFloat(data.healthInsurance) || safetyNetData.healthInsurance.value,
        provider: data.healthInsuranceProvider || safetyNetData.healthInsurance.provider,
        renewalDate: data.healthInsuranceRenewal || safetyNetData.healthInsurance.renewalDate,
      },
      lifeInsurance: {
        ...safetyNetData.lifeInsurance,
        value: parseFloat(data.lifeInsurance) || safetyNetData.lifeInsurance.value,
        provider: data.lifeInsuranceProvider || safetyNetData.lifeInsurance.provider,
        renewalDate: data.lifeInsuranceRenewal || safetyNetData.lifeInsurance.renewalDate,
      },
      epf: {
        ...safetyNetData.epf,
        value: parseFloat(data.epfBalance) || safetyNetData.epf.value,
        uanNumber: data.epfUan || safetyNetData.epf.uanNumber,
      },
      otherSavings: {
        ...safetyNetData.otherSavings,
        value: parseFloat(data.otherSavings) || safetyNetData.otherSavings.value,
        type: data.otherSavingsType || safetyNetData.otherSavings.type,
      }
    };
    
    setSafetyNetData(updatedSafetyNetData);
  };

  const handlePortfolioSummaryClick = (asset) => {
    // Get the tab index based on asset type
    let tabIndex = 0; // Default to 'All'
    
    if (asset.name === 'Stocks') {
      tabIndex = 1; // Stocks tab
    } else if (asset.name === 'Mutual Funds') {
      tabIndex = 2; // Mutual Funds tab
    } else if (asset.name === 'Cryptocurrency') {
      tabIndex = 3; // Crypto tab
    }
    
    // Navigate to Portfolio page with the selected tab
    navigate(`/portfolio?tab=${tabIndex}`);
  };

  const handleGoalClick = (goal) => {
    // If this is a API-sourced goal, the properties will be different
    // than our mock data goals
    const isApiGoal = goal.id && goal.targetAmount;
    
    // Convert the goal data to the format expected by GoalDetailsModal
    const formattedGoal = isApiGoal ? {
      id: goal.id,
      name: goal.name,
      icon: API.getGoalIcon(goal.category),
      goalType: goal.category ? goal.category.toLowerCase() : 'other',
      priority: goal.targetDate < new Date() ? 'high' : 'medium',
      deadline: goal.targetDate,
      targetAmount: goal.targetAmount,
      currentAmount: goal.currentAmount,
      progressPercent: Math.round((goal.currentAmount / goal.targetAmount) * 100),
      description: goal.description || `${goal.name} savings goal`,
      monthlyContribution: Math.round(goal.targetAmount / 12) // Default to target/12
    } : {
      id: goal.name,
      name: goal.name,
      icon: goal.icon,
      goalType: goal.name.toLowerCase().replace(' ', '_'),
      priority: goal.priority.toLowerCase(),
      deadline: new Date(goal.date).toISOString(),
      targetAmount: goal.target,
      currentAmount: goal.value,
      progressPercent: goal.progress,
      description: `${goal.name} savings goal`,
      monthlyContribution: goal.monthly
    };
    
    setSelectedGoal(formattedGoal);
    setIsGoalDetailsModalOpen(true);
  };
  
  const handleCloseGoalDetails = () => {
    setIsGoalDetailsModalOpen(false);
    setSelectedGoal(null);
  };

  // Handle notification close
  const handleCloseNotification = () => {
    setNotification({...notification, open: false});
  };

  return (
    <Box>
      {/* API Status Notifications */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity}>
          {notification.message}
        </Alert>
      </Snackbar>
      {/* Portfolio Value Card */}
      <GradientCard elevation={3} sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
            <Typography variant="subtitle2" sx={{ opacity: 0.8 }}>
              Total Portfolio Value
            </Typography>
            <IconButton 
              size="small" 
              onClick={toggleAmountVisibility}
              sx={{ 
                bgcolor: 'rgba(255, 255, 255, 0.2)',
                color: 'white',
                '&:hover': {
                  bgcolor: 'rgba(255, 255, 255, 0.3)',
                }
              }}
            >
              {isAmountHidden ? <VisibilityOffIcon fontSize="small" /> : <VisibilityIcon fontSize="small" />}
            </IconButton>
          </Box>
          
          {loading.portfolio ? (
            <CircularProgress size={24} color="inherit" sx={{ my: 2 }} />
          ) : error.portfolio ? (
            <Alert severity="error" sx={{ my: 1 }}>{error.portfolio}</Alert>
          ) : (
            <>
              <Typography variant="h4" sx={{ fontWeight: 700, my: 0.5 }}>
                {isAmountHidden ? '••••••' : `₹${(apiPortfolioData?.overview?.current || portfolioValue.current).toLocaleString('en-IN')}`}
              </Typography>
              
              <Stack direction="row" alignItems="center" spacing={1}>
                {apiPortfolioData?.overview ? (
                  <PerformanceChip
                    gain={apiPortfolioData.overview.returns > 0}
                    label={isAmountHidden ? '••••••' : `${apiPortfolioData.overview.returns > 0 ? '+' : ''}₹${apiPortfolioData.overview.returns.toLocaleString('en-IN')}`}
                    icon={apiPortfolioData.overview.returns > 0 ? <ArrowUpwardIcon fontSize="small" /> : <ArrowDownwardIcon fontSize="small" />}
                    size="small"
                  />
                ) : (
                  <PerformanceChip
                    gain={portfolioValue.change > 0}
                    label={isAmountHidden ? '••••••' : `${portfolioValue.change > 0 ? '+' : ''}₹${portfolioValue.change.toLocaleString('en-IN')}`}
                    icon={portfolioValue.change > 0 ? <ArrowUpwardIcon fontSize="small" /> : <ArrowDownwardIcon fontSize="small" />}
                    size="small"
                  />
                )}
                <Typography variant="body2" color="white" sx={{ opacity: 0.8 }}>
                  {apiPortfolioData?.overview ? 
                    `${apiPortfolioData.overview.returnsPercent > 0 ? '+' : ''}${apiPortfolioData.overview.returnsPercent}% overall` :
                    `${portfolioValue.changePercent > 0 ? '+' : ''}${portfolioValue.changePercent}% today`
                  }
                </Typography>
              </Stack>
              
              <Box sx={{ height: 100, mt: 3 }}>
                <Line 
                  data={apiPortfolioData?.history && Array.isArray(apiPortfolioData.history) ? {
                    labels: apiPortfolioData.history.map(item => item.date),
                    datasets: [{
                      data: apiPortfolioData.history.map(item => item.value),
                      borderColor: '#FFFFFF',
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      fill: true,
                    }]
                  } : chartData} 
                  options={chartOptions} 
                />
              </Box>
            </>
          )}
        </CardContent>
      </GradientCard>

      {/* Quick Actions */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>Quick Actions</Typography>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Card 
              variant="outlined" 
              sx={{ 
                cursor: 'pointer',
                '&:hover': {
                  boxShadow: 2
                }
              }}
              onClick={handleOpenInvestmentModal}
            >
              <CardContent sx={{ textAlign: 'center', p: 2 }}>
                <TrendingUpIcon color="primary" />
                <Typography variant="body2" sx={{ mt: 1 }}>Add Investments</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={4}>
            <Card 
              variant="outlined"
              sx={{ 
                cursor: 'pointer',
                '&:hover': {
                  boxShadow: 2
                }
              }}
              onClick={handleOpenWithdrawalModal}
            >
              <CardContent sx={{ textAlign: 'center', p: 2 }}>
                <TrendingDownIcon color="secondary" />
                <Typography variant="body2" sx={{ mt: 1 }}>Add Withdraw</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={4}>
            <Card 
              variant="outlined"
              sx={{ 
                cursor: 'pointer',
                '&:hover': {
                  boxShadow: 2
                }
              }}
              onClick={handleOpenGoalModal}
            >
              <CardContent sx={{ textAlign: 'center', p: 2 }}>
                <AddIcon color="info" />
                <Typography variant="body2" sx={{ mt: 1 }}>Add Goal</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>

      {/* Asset Allocation */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>Asset Allocation</Typography>
        <Card>
          <CardContent>
            {Array.isArray(assetAllocation) && assetAllocation.map((asset) => (
              <Box key={asset.type} sx={{ mb: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                  <Typography variant="body2">{asset.type}</Typography>
                  <Typography variant="body2" fontWeight="500">{asset.value}%</Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={asset.value} 
                  sx={{ 
                    height: 8, 
                    borderRadius: 4,
                    bgcolor: 'rgba(0,0,0,0.09)',
                    '& .MuiLinearProgress-bar': {
                      bgcolor: asset.color 
                    }
                  }} 
                />
              </Box>
            ))}
          </CardContent>
        </Card>
      </Box>

      {/* Top Investments */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6">Top Investments</Typography>
          <Button color="primary" size="small">View All</Button>
        </Box>
        
        <Grid container spacing={2}>
          {Array.isArray(topInvestments) && topInvestments.map((investment) => (
            <Grid item xs={6} key={investment.symbol}>
              <AssetCard>
                <CardContent sx={{ p: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Avatar sx={{ bgcolor: 'rgba(83, 103, 255, 0.1)', color: 'primary.main', width: 40, height: 40 }}>
                      {investment.icon}
                    </Avatar>
                    <IconButton size="small">
                      <MoreVertIcon fontSize="small" />
                    </IconButton>
                  </Box>
                  
                  <Typography variant="subtitle2" sx={{ mt: 1 }}>{investment.name}</Typography>
                  <Typography variant="body2" color="text.secondary">{investment.symbol}</Typography>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1, alignItems: 'center' }}>
                    <Typography variant="subtitle2">
                      {isAmountHidden ? '••••••' : `₹${investment.price.toLocaleString('en-IN')}`}
                    </Typography>
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        color: investment.change > 0 ? '#00C087' : '#FF5757',
                        display: 'flex',
                        alignItems: 'center' 
                      }}
                    >
                      {investment.change > 0 ? <ArrowUpwardIcon fontSize="inherit" sx={{ mr: 0.5 }}/> : <ArrowDownwardIcon fontSize="inherit" sx={{ mr: 0.5 }}/>
                      }
                      {Math.abs(investment.change)}%
                    </Typography>
                  </Box>
                </CardContent>
              </AssetCard>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Financial Safety Net Section */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6">Financial Safety Net</Typography>
          <Button 
            color="primary" 
            size="small" 
            startIcon={<ShieldIcon />}
            onClick={handleOpenSafetyNetModal}
          >
            Update Safety Net
          </Button>
        </Box>
        
        <Card>
          <CardContent>
            <Grid container spacing={2}>
              {/* Emergency Fund */}
              <Grid item xs={12} sm={6} md={4}>
                <Card variant="outlined" sx={{ height: '100%', borderRadius: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Avatar sx={{ bgcolor: safetyNetData.emergencyFund.color + '40', color: safetyNetData.emergencyFund.color }}>
                        {safetyNetData.emergencyFund.icon}
                      </Avatar>
                      <Typography 
                        variant="caption" 
                        sx={{ 
                          bgcolor: safetyNetData.emergencyFund.progress >= 75 ? '#e6f7ed' : '#fff8e6', 
                          color: safetyNetData.emergencyFund.progress >= 75 ? '#00C087' : '#FFB800',
                          px: 1,
                          py: 0.5,
                          borderRadius: 1,
                          fontWeight: 500
                        }}
                      >
                        {safetyNetData.emergencyFund.progress}% funded
                      </Typography>
                    </Box>
                    
                    <Typography variant="subtitle1" fontWeight={500} sx={{ mt: 2 }}>Emergency Fund</Typography>
                    
                    <Box sx={{ mt: 1, mb: 0.5 }}>
                      <Typography variant="body2" color="text.secondary">Current Balance</Typography>
                      <Typography variant="h6">
                        {isAmountHidden ? '••••••' : `₹${safetyNetData.emergencyFund.value.toLocaleString('en-IN')}`}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">Target Amount</Typography>
                      <Typography variant="body1">
                        {isAmountHidden ? '••••••' : `₹${safetyNetData.emergencyFund.target.toLocaleString('en-IN')}`}
                      </Typography>
                    </Box>
                    
                    <LinearProgress 
                      variant="determinate" 
                      value={safetyNetData.emergencyFund.progress} 
                      sx={{ 
                        mt: 2,
                        height: 6, 
                        borderRadius: 3,
                        bgcolor: 'rgba(0,0,0,0.09)',
                        '& .MuiLinearProgress-bar': {
                          bgcolor: safetyNetData.emergencyFund.color 
                        }
                      }} 
                    />
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Health Insurance */}
              <Grid item xs={12} sm={6} md={4}>
                <Card variant="outlined" sx={{ height: '100%', borderRadius: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Avatar sx={{ bgcolor: safetyNetData.healthInsurance.color + '40', color: safetyNetData.healthInsurance.color }}>
                        {safetyNetData.healthInsurance.icon}
                      </Avatar>
                      <Chip 
                        label="Active" 
                        size="small" 
                        color="success" 
                        variant="outlined" 
                      />
                    </Box>
                    
                    <Typography variant="subtitle1" fontWeight={500} sx={{ mt: 2 }}>Health Insurance</Typography>
                    
                    <Box sx={{ mt: 1, mb: 0.5 }}>
                      <Typography variant="body2" color="text.secondary">Coverage Amount</Typography>
                      <Typography variant="h6">
                        {isAmountHidden ? '••••••' : `₹${safetyNetData.healthInsurance.value.toLocaleString('en-IN')}`}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">Provider</Typography>
                      <Typography variant="body1">
                        {safetyNetData.healthInsurance.provider}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">Renewal Date</Typography>
                      <Typography variant="body1">
                        {new Date(safetyNetData.healthInsurance.renewalDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Life Insurance */}
              <Grid item xs={12} sm={6} md={4}>
                <Card variant="outlined" sx={{ height: '100%', borderRadius: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Avatar sx={{ bgcolor: safetyNetData.lifeInsurance.color + '40', color: safetyNetData.lifeInsurance.color }}>
                        {safetyNetData.lifeInsurance.icon}
                      </Avatar>
                      <Chip 
                        label="Active" 
                        size="small" 
                        color="success" 
                        variant="outlined" 
                      />
                    </Box>
                    
                    <Typography variant="subtitle1" fontWeight={500} sx={{ mt: 2 }}>Life Insurance</Typography>
                    
                    <Box sx={{ mt: 1, mb: 0.5 }}>
                      <Typography variant="body2" color="text.secondary">Coverage Amount</Typography>
                      <Typography variant="h6">
                        {isAmountHidden ? '••••••' : `₹${safetyNetData.lifeInsurance.value.toLocaleString('en-IN')}`}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">Provider</Typography>
                      <Typography variant="body1">
                        {safetyNetData.lifeInsurance.provider}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">Renewal Date</Typography>
                      <Typography variant="body1">
                        {new Date(safetyNetData.lifeInsurance.renewalDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* EPF */}
              <Grid item xs={12} sm={6} md={4}>
                <Card variant="outlined" sx={{ height: '100%', borderRadius: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Avatar sx={{ bgcolor: safetyNetData.epf.color + '40', color: safetyNetData.epf.color }}>
                        {safetyNetData.epf.icon}
                      </Avatar>
                    </Box>
                    
                    <Typography variant="subtitle1" fontWeight={500} sx={{ mt: 2 }}>EPF Balance</Typography>
                    
                    <Box sx={{ mt: 1, mb: 0.5 }}>
                      <Typography variant="body2" color="text.secondary">Current Balance</Typography>
                      <Typography variant="h6">
                        {isAmountHidden ? '••••••' : `₹${safetyNetData.epf.value.toLocaleString('en-IN')}`}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">UAN Number</Typography>
                      <Typography variant="body1">
                        {isAmountHidden ? '••••••' : safetyNetData.epf.uanNumber}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Other Savings */}
              <Grid item xs={12} sm={6} md={4}>
                <Card variant="outlined" sx={{ height: '100%', borderRadius: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Avatar sx={{ bgcolor: safetyNetData.otherSavings.color + '40', color: safetyNetData.otherSavings.color }}>
                        {safetyNetData.otherSavings.icon}
                      </Avatar>
                    </Box>
                    
                    <Typography variant="subtitle1" fontWeight={500} sx={{ mt: 2 }}>{safetyNetData.otherSavings.type}</Typography>
                    
                    <Box sx={{ mt: 1, mb: 0.5 }}>
                      <Typography variant="body2" color="text.secondary">Current Value</Typography>
                      <Typography variant="h6">
                        {isAmountHidden ? '••••••' : `₹${safetyNetData.otherSavings.value.toLocaleString('en-IN')}`}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Add New Safety Net Component Button */}
              <Grid item xs={12} sm={6} md={4}>
                <Card 
                  variant="outlined" 
                  sx={{ 
                    height: '100%', 
                    borderRadius: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    '&:hover': {
                      bgcolor: 'rgba(83, 103, 255, 0.04)',
                    }
                  }}
                  onClick={handleOpenSafetyNetModal}
                >
                  <CardContent sx={{ textAlign: 'center' }}>
                    <Avatar sx={{ bgcolor: 'rgba(83, 103, 255, 0.1)', color: 'primary.main', mx: 'auto', mb: 2 }}>
                      <AddIcon />
                    </Avatar>
                    <Typography variant="subtitle1" fontWeight={500}>Add New Component</Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      Track PPF, NPS, or other financial safety nets
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Box>

      {/* Goal Summary */}
      
      
      {/* Market Insights */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>Market Insights</Typography>
        <Card>
          <CardContent>
            <Typography variant="subtitle1" fontWeight="500">Market Update</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Sensex and Nifty rose by 1.2% and 1.3% respectively. Tech stocks showing strong momentum.
            </Typography>
            <Button color="primary" size="small" sx={{ mt: 2 }}>Read More</Button>
          </CardContent>
        </Card>
      </Box>

      {/* Portfolio Summary */}
      <Box sx={{ mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6">Portfolio Summary</Typography>
          <Button 
            color="primary" 
            size="small" 
            startIcon={<AddIcon />}
            onClick={handleOpenInvestmentModal}
          >
            New Investment
          </Button>
        </Box>
        <Card>
          <CardContent>
            <Grid container spacing={2}>
              {/* Use the mock portfolioData array as a fallback if API data isn't in the expected format */}
              {(Array.isArray(apiPortfolioData) ? apiPortfolioData : portfolioData).map((asset) => (
                <Grid item xs={6} sm={3} key={asset.name}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Avatar 
                      sx={{ 
                        bgcolor: asset.color, 
                        width: 56, 
                        height: 56, 
                        margin: '0 auto',
                        cursor: 'pointer',
                        transition: 'transform 0.2s',
                        '&:hover': {
                          transform: 'scale(1.1)',
                          boxShadow: 3
                        }
                      }}
                      onClick={() => handlePortfolioSummaryClick(asset)}
                    >
                      {asset.icon}
                    </Avatar>
                    <Typography variant="subtitle1" sx={{ mt: 1 }}>{asset.name}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {isAmountHidden ? '••••••' : `₹${asset.value.toLocaleString('en-IN')}`}
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mt: 0.5 }}>
                      <Typography variant="body2" sx={{ mr: 0.5, color: asset.change > 0 ? '#00C087' : '#FF5757' }}>
                        {asset.change > 0 ? <ArrowUpwardIcon fontSize="inherit" /> : <ArrowDownwardIcon fontSize="inherit" />}
                        {Math.abs(asset.change)}%
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>
      </Box>
      
      {/* Financial Goals */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6">Goals Summary</Typography>
          <Button 
            color="primary" 
            size="small" 
            startIcon={<AddIcon />}
            onClick={handleOpenGoalModal}
          >
            New Goal
          </Button>
        </Box>
        <Card>
          <CardContent>
            {loading.goals ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : error.goals ? (
              <Alert severity="error" sx={{ my: 1 }}>{error.goals}</Alert>
            ) : (
              <>
                <Grid container spacing={2}>
                  {/* Render API goals if available */}
                  {(goals && goals.length > 0) && goals.map((goal) => (
                    <Grid item xs={6} sm={2.4} key={goal.id || goal.name}>
                      <Box sx={{ textAlign: 'center' }}>
                        <Box sx={{ position: 'relative', width: 80, height: 80, mx: 'auto' }}>
                          {/* Background circle */}
                          <CircularProgress
                            variant="determinate"
                            value={100}
                            sx={{
                              color: 'rgba(0,0,0,0.1)',
                              width: '80px !important',
                              height: '80px !important',
                            }}
                          />
                          {/* Progress circle */}
                          <CircularProgress
                            variant="determinate"
                            value={goal.progressPercentage || goal.progressPercent || 0}
                            sx={{
                              color: goal.category === 'EMERGENCY_FUND' ? '#00C087' : 
                                     goal.category === 'HOME' ? '#FF9800' : 
                                     goal.category === 'EDUCATION' ? '#FF9800' : 
                                     goal.category === 'TRAVEL' ? '#5367FF' : 
                                     goal.category === 'RETIREMENT' ? '#5367FF' : '#FFB800',
                              position: 'absolute',
                              left: 0,
                              top: 0,
                              width: '80px !important',
                              height: '80px !important',
                            }}
                          />
                          {/* Centered icon */}
                          <Box
                            sx={{
                              position: 'absolute',
                              top: 0,
                              left: 0,
                              right: 0,
                              bottom: 0,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            <Avatar 
                              sx={{ 
                                bgcolor: 'rgba(83, 103, 255, 0.1)', 
                                color: goal.category === 'EMERGENCY_FUND' ? '#00C087' : 
                                       goal.category === 'HOME' ? '#FF9800' : 
                                       goal.category === 'EDUCATION' ? '#FF9800' : 
                                       goal.category === 'TRAVEL' ? '#5367FF' : 
                                       goal.category === 'RETIREMENT' ? '#5367FF' : '#FFB800',
                                width: 56, 
                                height: 56,
                                cursor: 'pointer',
                                transition: 'transform 0.2s',
                                '&:hover': {
                                  transform: 'scale(1.1)',
                                  boxShadow: 2
                                }
                              }}
                              onClick={() => handleGoalClick(goal)}
                            >
                              {goal.icon || API.getGoalIcon(goal.category)}
                            </Avatar>
                          </Box>
                        </Box>
                        <Typography variant="subtitle2" sx={{ mt: 1, fontWeight: 600 }}>{goal.name}</Typography>
                        <Typography variant="body2" color="text.secondary">
                          {isAmountHidden ? '••••••' : `₹${goal.currentAmount ? goal.currentAmount.toLocaleString('en-IN') : 0}`}
                        </Typography>
                        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mt: 0.5 }}>
                          <Chip 
                            label={`${Math.round(goal.progressPercentage || goal.progressPercent || 0)}% Complete`}
                            size="small"
                            sx={{ 
                              bgcolor: `rgba(83, 103, 255, 0.1)`,
                              color: goal.category === 'EMERGENCY_FUND' ? '#00C087' : 
                                     goal.category === 'HOME' ? '#FF9800' : 
                                     goal.category === 'EDUCATION' ? '#FF9800' : 
                                     goal.category === 'TRAVEL' ? '#5367FF' : 
                                     goal.category === 'RETIREMENT' ? '#5367FF' : '#FFB800',
                              fontSize: '0.7rem',
                              height: 24
                            }}
                          />
                        </Box>
                      </Box>
                    </Grid>
                  ))}
                  
                  {/* Render mock data if no API goals available */}
                  {(!goals || goals.length === 0) && financialGoalsData && financialGoalsData.map((goal) => (
                    <Grid item xs={6} sm={2.4} key={goal.name}>
                      <Box sx={{ textAlign: 'center' }}>
                        {/* Fallback to mock data rendering */}
                        <Box sx={{ position: 'relative', width: 80, height: 80, mx: 'auto' }}>
                          <CircularProgress
                            variant="determinate"
                            value={100}
                            sx={{
                              color: 'rgba(0,0,0,0.1)',
                              width: '80px !important',
                              height: '80px !important',
                            }}
                          />
                          <CircularProgress
                            variant="determinate"
                            value={goal.progress}
                            sx={{
                              color: goal.color,
                              position: 'absolute',
                              left: 0,
                              top: 0,
                              width: '80px !important',
                              height: '80px !important',
                            }}
                          />
                          <Box
                            sx={{
                              position: 'absolute',
                              top: 0,
                              left: 0,
                              right: 0,
                              bottom: 0,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            <Avatar 
                              sx={{ 
                                bgcolor: `${goal.color}15`, 
                                color: goal.color,
                                width: 56, 
                                height: 56,
                                cursor: 'pointer',
                                transition: 'transform 0.2s',
                                '&:hover': {
                                  transform: 'scale(1.1)',
                                  boxShadow: 2
                                }
                              }}
                              onClick={() => handleGoalClick(goal)}
                            >
                              {goal.icon}
                            </Avatar>
                          </Box>
                        </Box>
                        <Typography variant="subtitle2" sx={{ mt: 1, fontWeight: 600 }}>{goal.name}</Typography>
                        <Typography variant="body2" color="text.secondary">
                          {isAmountHidden ? '••••••' : `₹${goal.value.toLocaleString('en-IN')}`}
                        </Typography>
                        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mt: 0.5 }}>
                          <Chip 
                            label={`${goal.progress}% Complete`}
                            size="small"
                            sx={{ 
                              bgcolor: `${goal.color}15`,
                              color: goal.color,
                              fontSize: '0.7rem',
                              height: 24
                            }}
                          />
                        </Box>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 3, pt: 2, borderTop: '1px solid rgba(0,0,0,0.06)' }}>
                  <Typography variant="body2" color="text.secondary">
                    {(goals && goals.length > 0) ? `${goals.length} active goals` : `${financialGoalsData ? financialGoalsData.length : 0} active goals`}
                  </Typography>
                  <Button 
                    variant="outlined" 
                    size="small"
                    color="primary"
                    onClick={() => navigate('/portfolio#my-goals-section')}
                  >
                    View Details
                  </Button>
                </Box>
              </>
            )}
          </CardContent>
        </Card>
      </Box>
  
      {/* Add Investment Modal */}
      <AddInvestmentModal 
        open={isInvestmentModalOpen} 
        onClose={handleCloseInvestmentModal} 
      />

      {/* Add Withdrawal Modal */}
      <AddWithdrawalModal 
        open={isWithdrawalModalOpen} 
        onClose={handleCloseWithdrawalModal} 
      />

      {/* Add Goal Modal */}
      <AddGoalModal 
        open={isGoalModalOpen} 
        onClose={handleCloseGoalModal}
        onGoalsUpdate={handleGoalsUpdate} 
      />

      {/* Goal Details Modal */}
      <GoalDetailsModal 
        open={isGoalDetailsModalOpen} 
        onClose={handleCloseGoalDetails} 
        goal={selectedGoal}
      />

      {/* Financial Safety Net Modal */}
      <FinancialSafetyNetModal
        open={isSafetyNetModalOpen}
        onClose={handleCloseSafetyNetModal}
        onSave={handleSaveSafetyNet}
        initialValues={{
          emergencyFund: safetyNetData.emergencyFund.value.toString(),
          healthInsurance: safetyNetData.healthInsurance.value.toString(),
          healthInsuranceProvider: safetyNetData.healthInsurance.provider,
          healthInsuranceRenewal: safetyNetData.healthInsurance.renewalDate,
          lifeInsurance: safetyNetData.lifeInsurance.value.toString(),
          lifeInsuranceProvider: safetyNetData.lifeInsurance.provider,
          lifeInsuranceRenewal: safetyNetData.lifeInsurance.renewalDate,
          epfBalance: safetyNetData.epf.value.toString(),
          epfUan: safetyNetData.epf.uanNumber,
          otherSavings: safetyNetData.otherSavings.value.toString(),
          otherSavingsType: safetyNetData.otherSavings.type
        }}
      />
    </Box>
  );
};

export default Dashboard;