import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';
import API from '../utils/api';

// Create context
const WatchlistContext = createContext();

export const WatchlistProvider = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [watchlist, setWatchlist] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch watchlist data
  useEffect(() => {
    const fetchWatchlistData = async () => {
      if (!isAuthenticated) {
        setWatchlist([]);
        setLoading(false);
        return;
      }
      
      setLoading(true);
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 800));
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch watchlist data');
        setLoading(false);
      }
    };

    fetchWatchlistData();
  }, [isAuthenticated]);

  // Add an item to watchlist
  const addToWatchlist = async (item) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Check if already in watchlist
      const exists = watchlist.some(w => w.symbol === item.symbol);
      if (exists) throw new Error('Asset already in watchlist');
      
      // Generate new ID
      const newId = Math.max(...watchlist.map(w => w.id)) + 1;
      
      const newItem = {
        id: newId,
        name: item.name,
        symbol: item.symbol,
        price: item.price,
        change: item.change,
        icon: item.icon || '📊',
        notification: true,
        type: item.type
      };
      
      setWatchlist([...watchlist, newItem]);
      setLoading(false);
      return { success: true };
    } catch (err) {
      setError(err.message);
      setLoading(false);
      return { success: false, error: err.message };
    }
  };

  // Remove an item from watchlist
  const removeFromWatchlist = async (id) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setWatchlist(watchlist.filter(item => item.id !== id));
      setLoading(false);
      return { success: true };
    } catch (err) {
      setError(err.message);
      setLoading(false);
      return { success: false, error: err.message };
    }
  };

  // Toggle notification for watchlist item
  const toggleNotification = async (id) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      setWatchlist(
        watchlist.map(item => 
          item.id === id 
            ? { ...item, notification: !item.notification } 
            : item
        )
      );
      
      setLoading(false);
      return { success: true };
    } catch (err) {
      setError(err.message);
      setLoading(false);
      return { success: false, error: err.message };
    }
  };

  // Update prices (simulates real-time updates)
  const updatePrices = async () => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setWatchlist(
        watchlist.map(item => {
          // Generate random price change between -3% and +3%
          const changePercent = (Math.random() * 6 - 3) / 100;
          const newPrice = item.price * (1 + changePercent);
          return {
            ...item,
            price: parseFloat(newPrice.toFixed(2)),
            change: parseFloat((changePercent * 100).toFixed(2))
          };
        })
      );
      
      return { success: true };
    } catch (err) {
      setError(err.message);
      return { success: false, error: err.message };
    }
  };

  return (
    <WatchlistContext.Provider
      value={{
        watchlist,
        loading,
        error,
        addToWatchlist,
        removeFromWatchlist,
        toggleNotification,
        updatePrices
      }}
    >
      {children}
    </WatchlistContext.Provider>
  );
};

// Custom hook to use watchlist context
export const useWatchlist = () => {
  const context = useContext(WatchlistContext);
  if (!context) {
    throw new Error('useWatchlist must be used within a WatchlistProvider');
  }
  return context;
};