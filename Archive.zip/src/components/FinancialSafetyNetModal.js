import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  Typography,
  Box,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Divider,
  FormHelperText
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import SaveIcon from '@mui/icons-material/Save';
import { styled } from '@mui/system';

const StyledDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(3),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1, 3, 2),
  },
}));

const AddFinancialSafetyNetModal = ({ open, onClose, onSave, initialValues = {} }) => {
  const [formData, setFormData] = useState({
    emergencyFund: initialValues.emergencyFund || '',
    healthInsurance: initialValues.healthInsurance || '',
    healthInsuranceProvider: initialValues.healthInsuranceProvider || '',
    healthInsuranceRenewal: initialValues.healthInsuranceRenewal || '',
    lifeInsurance: initialValues.lifeInsurance || '',
    lifeInsuranceProvider: initialValues.lifeInsuranceProvider || '',
    lifeInsuranceRenewal: initialValues.lifeInsuranceRenewal || '',
    epfBalance: initialValues.epfBalance || '',
    epfUan: initialValues.epfUan || '',
    otherSavings: initialValues.otherSavings || '',
    otherSavingsType: initialValues.otherSavingsType || 'Fixed Deposit'
  });
  
  const [errors, setErrors] = useState({});
  
  const validateFields = () => {
    const newErrors = {};
    
    if (formData.emergencyFund !== '' && isNaN(formData.emergencyFund)) {
      newErrors.emergencyFund = 'Please enter a valid amount';
    }
    
    if (formData.healthInsurance !== '' && isNaN(formData.healthInsurance)) {
      newErrors.healthInsurance = 'Please enter a valid amount';
    }
    
    if (formData.lifeInsurance !== '' && isNaN(formData.lifeInsurance)) {
      newErrors.lifeInsurance = 'Please enter a valid amount';
    }
    
    if (formData.epfBalance !== '' && isNaN(formData.epfBalance)) {
      newErrors.epfBalance = 'Please enter a valid amount';
    }
    
    if (formData.otherSavings !== '' && isNaN(formData.otherSavings)) {
      newErrors.otherSavings = 'Please enter a valid amount';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when field is changed
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };
  
  const handleSubmit = () => {
    if (validateFields()) {
      onSave(formData);
      onClose();
    }
  };

  return (
    <StyledDialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Typography variant="h6">Update Financial Safety Net</Typography>
          <IconButton edge="end" color="inherit" onClick={onClose} aria-label="close">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      
      <DialogContent dividers>
        <Typography variant="body2" color="text.secondary" paragraph>
          Keep track of your financial safety net. These details help you monitor your financial security and ensure you're adequately protected.
        </Typography>
        
        <Box mb={3}>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            Emergency Fund
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Emergency Fund Balance"
                name="emergencyFund"
                value={formData.emergencyFund}
                onChange={handleChange}
                placeholder="Enter amount"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
                error={!!errors.emergencyFund}
                helperText={errors.emergencyFund}
              />
            </Grid>
          </Grid>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Box mb={3}>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            Health Insurance
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Coverage Amount"
                name="healthInsurance"
                value={formData.healthInsurance}
                onChange={handleChange}
                placeholder="Enter amount"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
                error={!!errors.healthInsurance}
                helperText={errors.healthInsurance}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Insurance Provider"
                name="healthInsuranceProvider"
                value={formData.healthInsuranceProvider}
                onChange={handleChange}
                placeholder="e.g., Star Health, HDFC ERGO"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Policy Renewal Date"
                name="healthInsuranceRenewal"
                type="date"
                value={formData.healthInsuranceRenewal}
                onChange={handleChange}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
          </Grid>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Box mb={3}>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            Life Insurance
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Coverage Amount"
                name="lifeInsurance"
                value={formData.lifeInsurance}
                onChange={handleChange}
                placeholder="Enter amount"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
                error={!!errors.lifeInsurance}
                helperText={errors.lifeInsurance}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Insurance Provider"
                name="lifeInsuranceProvider"
                value={formData.lifeInsuranceProvider}
                onChange={handleChange}
                placeholder="e.g., LIC, HDFC Life"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Policy Renewal Date"
                name="lifeInsuranceRenewal"
                type="date"
                value={formData.lifeInsuranceRenewal}
                onChange={handleChange}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
          </Grid>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Box mb={3}>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            EPF Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="EPF Balance"
                name="epfBalance"
                value={formData.epfBalance}
                onChange={handleChange}
                placeholder="Enter amount"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
                error={!!errors.epfBalance}
                helperText={errors.epfBalance}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="UAN Number"
                name="epfUan"
                value={formData.epfUan}
                onChange={handleChange}
                placeholder="Enter UAN number"
              />
            </Grid>
          </Grid>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Box>
          <Typography variant="subtitle1" fontWeight={600} gutterBottom>
            Other Security Savings
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Type</InputLabel>
                <Select
                  name="otherSavingsType"
                  value={formData.otherSavingsType}
                  onChange={handleChange}
                  label="Type"
                >
                  <MenuItem value="Fixed Deposit">Fixed Deposit</MenuItem>
                  <MenuItem value="PPF">PPF</MenuItem>
                  <MenuItem value="NPS">NPS</MenuItem>
                  <MenuItem value="Gold">Gold</MenuItem>
                  <MenuItem value="Real Estate">Real Estate</MenuItem>
                  <MenuItem value="Government Bonds">Government Bonds</MenuItem>
                  <MenuItem value="Other">Other</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Amount"
                name="otherSavings"
                value={formData.otherSavings}
                onChange={handleChange}
                placeholder="Enter amount"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
                error={!!errors.otherSavings}
                helperText={errors.otherSavings}
              />
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      
      <Box sx={{ mt: 2, p: 2, bgcolor: '#F7FAFC', borderRadius: 1 }}>
        <Typography variant="subtitle1" fontWeight={600} gutterBottom>
          💡 Financial Safety Tips
        </Typography>

        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <Box sx={{ p: 2, border: '1px solid #E0E7FF', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" fontWeight={600} color="primary.main">
                Emergency Fund
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Aim for 3-6 months of expenses in an easily accessible account. Start with a ₹50,000 mini emergency fund if you're just beginning.
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <Box sx={{ p: 2, border: '1px solid #E0E7FF', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" fontWeight={600} color="primary.main">
                Insurance Coverage
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Health insurance should cover at least ₹10L per family member. Life insurance coverage should be 10-15x your annual income.
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <Box sx={{ p: 2, border: '1px solid #E0E7FF', borderRadius: 1, height: '100%' }}>
              <Typography variant="subtitle2" fontWeight={600} color="primary.main">
                Retirement Planning
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Diversify your retirement savings with EPF, NPS, and other tax-advantaged investments. Aim to save at least 15% of your income.
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box>

      <DialogActions>
        <Button onClick={onClose} color="inherit">Cancel</Button>
        <Button 
          onClick={handleSubmit} 
          variant="contained" 
          color="primary"
          startIcon={<SaveIcon />}
        >
          Save Changes
        </Button>
      </DialogActions>
    </StyledDialog>
  );
};

export default AddFinancialSafetyNetModal;
