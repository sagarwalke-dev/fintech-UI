import React, { useState, useEffect } from 'react';
import { 
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  MenuItem,
  Typography,
  InputAdornment,
  CircularProgress,
  Box,
  Autocomplete,
  Snackbar,
  Alert
} from '@mui/material';
import { API } from '../utils/api';
import { formatCurrency } from '../utils/formatters';

/**
 * Modal component for adding new investments to portfolio
 * 
 * @param {Object} props
 * @param {boolean} props.open - Whether the modal is open
 * @param {function} props.onClose - Function to call when closing the modal
 * @param {Object} [props.initialValues] - Initial values for the form
 */
const AddInvestmentModal = ({ open, onClose, initialValues = {} }) => {
  const [loading, setLoading] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [error, setError] = useState('');
  const [notification, setNotification] = useState({ open: false, type: 'success', message: '' });
  
  const [formData, setFormData] = useState({
    assetName: initialValues.assetName || '',
    assetSymbol: initialValues.assetSymbol || '',
    quantity: initialValues.quantity || '',
    priceAtPurchase: initialValues.priceAtPurchase || '',
    type: initialValues.type || 'STOCK',
    icon: initialValues.icon || '',
    amount: initialValues.amount || ''
  });
  
  // Search for assets when typing in the name field
  useEffect(() => {
    const searchAssets = async () => {
      if (!formData.assetName || formData.assetName.length < 2) {
        setSearchResults([]);
        return;
      }
      
      setSearchLoading(true);
      try {
        const results = await API.searchAssets(formData.assetName);
        setSearchResults(results);
      } catch (error) {
        console.error('Error searching assets:', error);
      } finally {
        setSearchLoading(false);
      }
    };
    
    const timeoutId = setTimeout(searchAssets, 500);
    return () => clearTimeout(timeoutId);
  }, [formData.assetName]);
  
  // Calculate total value
  const totalValue = 
    formData.quantity && formData.priceAtPurchase ? 
    Number(formData.quantity) * Number(formData.priceAtPurchase) : 0;
  
  // Update the amount field when quantity or price changes
  useEffect(() => {
    if (totalValue > 0) {
      setFormData(prev => ({...prev, amount: totalValue}));
    }
  }, [totalValue]);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  
  const handleAssetSelect = (event, value) => {
    if (value) {
      setFormData({
        ...formData,
        assetName: value.name,
        assetSymbol: value.symbol,
        type: mapTypeToBackend(value.type) || formData.type,
        // Set a default price if we don't have it
        priceAtPurchase: value.price || formData.priceAtPurchase
      });
    }
  };
  
  // Map frontend type to backend enum value
  const mapTypeToBackend = (type) => {
    const typeMap = {
      'stocks': 'STOCK',
      'crypto': 'CRYPTO',
      'mutualFunds': 'MUTUAL_FUND',
      'etfs': 'ETF',
      'bonds': 'BOND',
      'other': 'OTHER'
    };
    
    return typeMap[type] || 'OTHER';
  };
  
  const handleCloseNotification = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setNotification({ ...notification, open: false });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    // Validation
    if (!formData.assetName || !formData.quantity || !formData.priceAtPurchase) {
      setError('Please fill in all required fields');
      return;
    }
    
    if (isNaN(formData.quantity) || Number(formData.quantity) <= 0) {
      setError('Please enter a valid quantity');
      return;
    }
    
    if (isNaN(formData.priceAtPurchase) || Number(formData.priceAtPurchase) <= 0) {
      setError('Please enter a valid price');
      return;
    }
    
    setLoading(true);
    try {
      // Format the investment data for the backend API
      const investmentData = {
        assetName: formData.assetName,
        assetSymbol: formData.assetSymbol,
        quantity: Number(formData.quantity),
        priceAtPurchase: Number(formData.priceAtPurchase),
        amount: totalValue,
        type: formData.type,
        date: new Date().toISOString().split('T')[0] // YYYY-MM-DD format
      };
      
      // Call the API to add the investment
      const result = await API.addInvestment(investmentData);
      
      if (result && result.id) {
        // Show success notification
        setNotification({
          open: true,
          type: 'success',
          message: '🎉 Investment added successfully!'
        });
        
        // Reset form data
        setFormData({
          assetName: '',
          assetSymbol: '',
          quantity: '',
          priceAtPurchase: '',
          type: 'STOCK',
          icon: '',
          amount: ''
        });
        
        // Close modal after a short delay to show notification
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        throw new Error('Failed to add investment');
      }
    } catch (err) {
      setError(err.message || 'An error occurred');
      // Show error notification
      setNotification({
        open: true,
        type: 'error',
        message: `❌ ${err.message || 'An error occurred'}`
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Dialog open={open} onClose={loading ? null : onClose} maxWidth="sm" fullWidth>
        <DialogTitle>Add New Investment</DialogTitle>
        
        <form onSubmit={handleSubmit}>
          <DialogContent>
            {error && (
              <Typography color="error" sx={{ mb: 2 }}>
                {error}
              </Typography>
            )}
            
            {/* Form fields - unchanged */}
            <Grid container spacing={2}>
              {/* <Grid item xs={12}>
                <Autocomplete
                  options={searchResults}
                  loading={searchLoading}
                  getOptionLabel={(option) => `${option.name} - ${option.name}`}
                  onChange={handleAssetSelect}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      name="name"
                      label="Search Asset"
                      variant="outlined"
                      fullWidth
                      required
                      value={formData.name}
                      onChange={handleChange}
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {searchLoading ? <CircularProgress color="inherit" size={20} /> : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Grid> */}
              
              <Grid item xs={12} sm={6}>
                <TextField
                  name="assetName"
                  label="Name"
                  variant="outlined"
                  fullWidth
                  required
                  value={formData.assetName}
                  onChange={handleChange}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  name="type"
                  label="Asset Type"
                  variant="outlined"
                  fullWidth
                  required
                  value={formData.type}
                  onChange={handleChange}
                >
                  <MenuItem value="stocks">Stocks</MenuItem>
                  <MenuItem value="crypto">Crypto</MenuItem>
                  <MenuItem value="mutualFunds">Mutual Funds</MenuItem>
                  <MenuItem value="fd">Fixed Deposit</MenuItem>
                  <MenuItem value="us_stocks">US Stocks</MenuItem>
                  <MenuItem value="etfs">ETF</MenuItem>
                  <MenuItem value="bonds">Bonds</MenuItem>
                </TextField>
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  name="quantity"
                  label="Quantity / Units"
                  variant="outlined"
                  fullWidth
                  required
                  type="number"
                  inputProps={{ min: 0, step: "any" }}
                  value={formData.quantity}
                  onChange={handleChange}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  name="priceAtPurchase"
                  label="Purchase Price"
                  variant="outlined"
                  fullWidth
                  required
                  type="number"
                  inputProps={{ min: 0, step: "any" }}
                  value={formData.priceAtPurchase}
                  onChange={handleChange}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                  }}
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  name="icon"
                  label="Icon (Emoji)"
                  variant="outlined"
                  fullWidth
                  placeholder="🍏"
                  value={formData.icon}
                  onChange={handleChange}
                  helperText="Optional: Enter an emoji to represent this asset"
                />
              </Grid>
              
              {totalValue > 0 && (
                <Grid item xs={12}>
                  <Box sx={{ 
                    mt: 1, 
                    p: 2, 
                    bgcolor: 'background.paper', 
                    borderRadius: 1,
                    border: '1px solid',
                    borderColor: 'divider'
                  }}>
                    <Typography variant="body2" color="text.secondary">
                      Total Investment Value
                    </Typography>
                    <Typography variant="h6">
                      {formatCurrency(totalValue)}
                    </Typography>
                  </Box>
                </Grid>
              )}
            </Grid>
          </DialogContent>
          
          <DialogActions>
            <Button onClick={onClose} disabled={loading}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              variant="contained" 
              color="primary" 
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Add Investment'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>

      {/* Success/Error Notification */}
      <Snackbar 
        open={notification.open} 
        autoHideDuration={4000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseNotification} 
          severity={notification.type} 
          variant="filled" 
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default AddInvestmentModal;