/**
 * API utility functions for financial data
 * Integration with Spring Boot backend
 */

// Base URL for API calls
const API_BASE_URL = 'http://localhost:8080/api';

// Default user ID (in a real app, this would come from authentication)
const DEFAULT_USER_ID = 'demo-user-id';

/**
 * Helper function to get an appropriate icon for a financial goal
 * @param {string} goalType - The type of financial goal
 * @returns {string} An emoji icon representing the goal
 */
const getGoalIcon = (goalType) => {
  if (!goalType) return '🎯';
  
  switch(goalType.toLowerCase()) {
    case 'retirement':
      return '👴';
    case 'house':
    case 'housing':
      return '🏠';
    case 'travel':
      return '✈️';
    case 'car':
      return '🚗';
    case 'emergency':
      return '🚨';
    case 'education':
      return '🎓';
    case 'lifestyle':
      return '🏖️';
    case 'other':
    default:
      return '🎯';
  }
};

/**
 * Create API request with fetch
 * @param {string} endpoint - The API endpoint
 * @param {Object} options - Request options
 * @returns {Promise} - A promise that resolves to the API response
 */
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  
  // Default options
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'include', // Include cookies for session management if needed
  };
  
  // Merge default options with provided options
  const fetchOptions = {
    ...defaultOptions,
    ...options,
    headers: {
      ...defaultOptions.headers,
      ...options.headers,
    },
  };
  
  try {
    console.log(`API Request: ${options.method || 'GET'} ${url}`);
    const response = await fetch(url, fetchOptions);
    
    // Check if the request was successful
    if (!response.ok) {
      // Try to parse error message from response if available
      let errorMsg;
      try {
        const errorData = await response.json();
        errorMsg = errorData.message || `API request failed with status ${response.status}`;
      } catch (e) {
        errorMsg = `API request failed with status ${response.status}`;
      }
      throw new Error(errorMsg);
    }
    
    // Parse JSON response
    const data = await response.json();
    console.log(`API Response for ${url}:`, data);
    return data;
  } catch (error) {
    console.error(`API request error for ${url}:`, error);
    throw error;
  }
};

/**
 * Mock market data for popular assets
 * This data is not yet available from backend, so we'll keep it here
 */
const marketData = {
  stocks: [
    { symbol: 'AAPL', name: 'Apple Inc.' },
    { symbol: 'MSFT', name: 'Microsoft Corp.' },
    { symbol: 'GOOGL', name: 'Alphabet Inc.' },
    { symbol: 'AMZN', name: 'Amazon.com Inc.' },
    { symbol: 'TSLA', name: 'Tesla Inc.' },
    { symbol: 'META', name: 'Meta Platforms Inc.' },
    { symbol: 'NVDA', name: 'NVIDIA Corp.' },
    { symbol: 'RELIANCE.NS', name: 'Reliance Industries' },
    { symbol: 'TCS.NS', name: 'Tata Consultancy Services' },
    { symbol: 'HDFCBANK.NS', name: 'HDFC Bank Ltd.' },
    { symbol: 'INFY.NS', name: 'Infosys Ltd.' }
  ],
  crypto: [
    { symbol: 'BTC', name: 'Bitcoin' },
    { symbol: 'ETH', name: 'Ethereum' },
    { symbol: 'BNB', name: 'Binance Coin' },
    { symbol: 'SOL', name: 'Solana' },
    { symbol: 'ADA', name: 'Cardano' },
    { symbol: 'XRP', name: 'Ripple' },
    { symbol: 'DOT', name: 'Polkadot' },
    { symbol: 'AVAX', name: 'Avalanche' }
  ],
  mutualFunds: [
    { symbol: 'AXIS_BC', name: 'Axis Bluechip Fund' },
    { symbol: 'HDFC_TOP100', name: 'HDFC Top 100 Fund' },
    { symbol: 'SBI_SMALL', name: 'SBI Small Cap Fund' },
    { symbol: 'ICICI_TECH', name: 'ICICI Prudential Technology Fund' },
    { symbol: 'MIRAE_EMERG', name: 'Mirae Asset Emerging Bluechip' },
    { symbol: 'PARAG_FLEXI', name: 'Parag Parikh Flexi Cap Fund' }
  ]
};

/**
 * API functions - integrated with Spring Boot backend
 */
export const API = {
  /**
   * Check if the backend is available and responding
   * @returns {Promise<boolean>} True if backend is available
   */
  checkBackendStatus: async () => {
    try {
      // Try to get all users as a simple health check
      await apiRequest('/users');
      console.log('Backend connection successful');
      return true;
    } catch (error) {
      console.error('Backend connection failed:', error);
      return false;
    }
  },
  /**
   * Get portfolio data for a user
   * This combines data from multiple endpoints to create a comprehensive portfolio overview
   * @returns {Promise} Portfolio data
   */
  getPortfolio: async () => {
    try {
      // Get user's investments
      const investments = await apiRequest(`/investments/user/${DEFAULT_USER_ID}`);
      
      // Calculate totals and build the portfolio object
      let invested = 0;
      let current = 0;
      
      investments.forEach(investment => {
        invested += investment.amount;
        // For a real app, we would get current prices from another endpoint
        // For now we'll apply a random growth factor
        const growthFactor = 1 + (Math.random() * 0.2 - 0.05); // -5% to +15%
        current += investment.amount * growthFactor;
      });
      
      const returns = current - invested;
      const returnsPercent = (returns / invested) * 100;
      
      // Build the portfolio history (mock data for now)
      const monthsBack = 7;
      const history = [];
      
      for (let i = 0; i < monthsBack; i++) {
        const date = new Date();
        date.setMonth(date.getMonth() - (monthsBack - i - 1));
        
        // Progressive growth pattern with some randomness
        const progressFactor = (i / monthsBack) * 0.8 + 0.9 + (Math.random() * 0.06 - 0.03);
        const value = Math.round(invested * progressFactor);
        
        history.push({
          date: date.toISOString().split('T')[0],
          value
        });
      }
      
      // Add the current value as the last point
      history.push({
        date: new Date().toISOString().split('T')[0],
        value: Math.round(current)
      });
      
      // Calculate the asset allocation (mock data for now)
      const allocation = [
        { type: 'Stocks', value: 62.5, color: '#5367FF' },
        { type: 'Mutual Funds', value: 25.3, color: '#00C087' },
        { type: 'Crypto', value: 8.7, color: '#FF9800' },
        { type: 'Cash', value: 3.5, color: '#E0E0E0' }
      ];
      
      return {
        overview: {
          invested: Math.round(invested),
          current: Math.round(current),
          returns: Math.round(returns),
          returnsPercent: Math.round(returnsPercent * 100) / 100,
        },
        history,
        allocation
      };
    } catch (error) {
      console.error('Error fetching portfolio data:', error);
      throw error;
    }
  },

  /**
   * Get user's holdings (investments)
   * @returns {Promise} Holdings data
   */
  getHoldings: async () => {
    try {
      // Get the user's investments from the backend
      const investments = await apiRequest(`/investments/user/${DEFAULT_USER_ID}`);
      
      // Transform the raw investment data into the format expected by the UI
      return investments.map(investment => {
        // Calculate current price (in a real app, we'd get this from market data)
        const currentPrice = investment.priceAtPurchase * (1 + (Math.random() * 0.3 - 0.1)); // -10% to +20%
        const value = investment.quantity * currentPrice;
        const gain = value - investment.amount;
        const gainPercent = (gain / investment.amount) * 100;
        
        // Map the investment type to an icon
        const icons = {
          STOCK: '📈',
          CRYPTO: '₿',
          MUTUAL_FUND: '📊',
          ETF: '🔄',
          BOND: '📜',
          OTHER: '💰'
        };
        
        // Map investment type to lowercase string for UI
        const typeMap = {
          STOCK: 'stocks',
          CRYPTO: 'crypto',
          MUTUAL_FUND: 'mutualFunds',
          ETF: 'etfs',
          BOND: 'bonds',
          OTHER: 'other'
        };
        
        return {
          id: investment.id,
          name: investment.assetName,
          symbol: investment.assetSymbol,
          quantity: investment.quantity,
          avgPrice: investment.priceAtPurchase,
          currentPrice: currentPrice,
          value: Math.round(value * 100) / 100,
          gain: Math.round(gain * 100) / 100,
          gainPercent: Math.round(gainPercent * 100) / 100,
          allocation: 0, // This would be calculated based on total portfolio
          icon: icons[investment.type] || '💰',
          type: typeMap[investment.type] || 'other'
        };
      });
    } catch (error) {
      console.error('Error fetching holdings:', error);
      throw error;
    }
  },

  /**
   * Get market data for specified asset type
   * @param {string} type - Asset type ('stocks', 'crypto', 'mutualFunds')
   * @returns {Promise} Market data for the specified type
   */
  getMarketData: (type) => {
    // This data is static and not yet stored in the backend
    if (!marketData[type]) {
      return Promise.reject(new Error(`Unknown market data type: ${type}`));
    }
    return Promise.resolve(marketData[type]);
  },

  /**
   * Search for assets by query
   * @param {string} query - Search query
   * @returns {Promise} Search results
   */
  searchAssets: (query) => {
    const results = [];
    const lowercaseQuery = query.toLowerCase();
    
    // Search through all market data
    Object.keys(marketData).forEach((type) => {
      const matches = marketData[type].filter(
        (asset) => 
          asset.name.toLowerCase().includes(lowercaseQuery) || 
          asset.symbol.toLowerCase().includes(lowercaseQuery)
      );
      
      matches.forEach((match) => {
        results.push({
          ...match,
          type
        });
      });
    });
    
    return Promise.resolve(results);
  },

  /**
   * Get market news
   * @param {number} limit - Number of news items to retrieve
   * @returns {Promise} Market news data
   */
  getMarketNews: (limit = 5) => {
    // Mock news data (this would come from an actual news API in a real app)
    const news = [
      {
        id: 1,
        title: 'Fed signals potential interest rate cut later this year',
        source: 'Financial Times',
        time: '2h ago',
        image: '📊',
        category: 'Economy',
        url: '#'
      },
      {
        id: 2,
        title: 'NVIDIA stock surges after AI chip demand forecast increases',
        source: 'Bloomberg',
        time: '4h ago',
        image: '🖥️',
        category: 'Technology',
        url: '#'
      },
      {
        id: 3,
        title: 'Bitcoin approaching all-time high as institutional investment grows',
        source: 'CoinDesk',
        time: '6h ago',
        image: '₿',
        category: 'Crypto',
        url: '#'
      },
      {
        id: 4,
        title: 'Indian equity markets continue bullish trend amid strong economic data',
        source: 'Economic Times',
        time: '8h ago',
        image: '📈',
        category: 'Markets',
        url: '#'
      },
      {
        id: 5,
        title: 'New IPO listings to watch this month: TechVision AI leads the pack',
        source: 'Reuters',
        time: '10h ago',
        image: '🚀',
        category: 'IPO',
        url: '#'
      }
    ];
    
    return Promise.resolve(news.slice(0, limit));
  },

  /**
   * Get user's watchlist
   * @returns {Promise} Watchlist data
   */
  getWatchlist: async () => {
    try {
      const watchlistItems = await apiRequest(`/watchlist/user/${DEFAULT_USER_ID}`);
      
      // Transform the backend data to match the expected format
      return watchlistItems.map(item => {
        // Calculate a random change value for demo purposes
        const change = (Math.random() * 5 - 2.5).toFixed(2);
        
        // Map the asset type to an icon
        const icons = {
          STOCK: '📈',
          CRYPTO: '₿',
          MUTUAL_FUND: '📊',
          ETF: '🔄',
          BOND: '📜',
          OTHER: '💰'
        };
        
        // Map asset type to lowercase string for UI
        const typeMap = {
          STOCK: 'stocks',
          CRYPTO: 'crypto',
          MUTUAL_FUND: 'mutualFunds',
          ETF: 'etfs',
          BOND: 'bonds',
          OTHER: 'other'
        };
        
        return {
          id: item.id,
          name: item.assetName,
          symbol: item.assetSymbol,
          price: item.currentPrice,
          change: parseFloat(change),
          icon: icons[item.type] || '💰',
          notification: true,
          type: typeMap[item.type] || 'other'
        };
      });
    } catch (error) {
      console.error('Error fetching watchlist:', error);
      throw error;
    }
  },

  /**
   * Add item to watchlist
   * @param {object} item - Item to add to watchlist
   * @returns {Promise} Success status
   */
  addToWatchlist: async (item) => {
    try {
      // Format the item for the backend API
      const watchlistItem = {
        userId: DEFAULT_USER_ID,
        assetName: item.name,
        assetSymbol: item.symbol,
        currentPrice: item.price || 0,
        type: item.type ? item.type.toUpperCase() : 'OTHER'
      };
      
      // Send the POST request to add the item
      const response = await apiRequest('/watchlist', {
        method: 'POST',
        body: JSON.stringify(watchlistItem)
      });
      
      return { success: true, message: 'Added to watchlist', item: response };
    } catch (error) {
      console.error('Error adding to watchlist:', error);
      return { success: false, message: 'Failed to add to watchlist' };
    }
  },

  /**
   * Remove item from watchlist
   * @param {string} id - ID of item to remove
   * @returns {Promise} Success status
   */
  removeFromWatchlist: async (id) => {
    try {
      // Send DELETE request to remove the item
      await apiRequest(`/watchlist/${id}`, {
        method: 'DELETE'
      });
      
      return { success: true, message: 'Removed from watchlist' };
    } catch (error) {
      console.error('Error removing from watchlist:', error);
      return { success: false, message: 'Failed to remove from watchlist' };
    }
  },
  
  /**
   * Get financial goals for the user
   * @returns {Promise} Goals data
   */
  getGoals: async () => {
    try {
      const goals = await apiRequest(`/goals/user/${DEFAULT_USER_ID}`);
      
      // Transform backend data to match frontend expectations
      return goals.map(goal => {
        // Calculate progress percentage
        const progressPercent = Math.round((goal.currentAmount / goal.targetAmount) * 100);
        
        return {
          ...goal,
          progressPercent: progressPercent,
          // Ensure consistent property naming
          goalType: goal.category || goal.goalType,
          icon: getGoalIcon(goal.category || goal.goalType)
        };
      });
    } catch (error) {
      console.error('Error fetching goals:', error);
      throw error;
    }
  },
  
  /**
   * Create a new financial goal
   * @param {object} goal - Goal to create
   * @returns {Promise} Created goal
   */
  createGoal: async (goal) => {
    try {
      const newGoal = {
        ...goal,
        userId: DEFAULT_USER_ID
      };
      
      const response = await apiRequest('/goals', {
        method: 'POST',
        body: JSON.stringify(newGoal)
      });
      
      return response;
    } catch (error) {
      console.error('Error creating goal:', error);
      throw error;
    }
  },
  
  /**
   * Update goal progress
   * @param {string} goalId - ID of the goal to update
   * @param {number} progress - New progress value
   * @returns {Promise} Updated goal
   */
  updateGoalProgress: async (goalId, progress) => {
    try {
      const response = await apiRequest(`/goals/${goalId}/progress`, {
        method: 'PATCH',
        body: JSON.stringify({ progress })
      });
      
      return response;
    } catch (error) {
      console.error('Error updating goal progress:', error);
      throw error;
    }
  },
  
  /**
   * Get withdrawal history
   * @returns {Promise} Withdrawal history data
   */
  getWithdrawals: async () => {
    try {
      const withdrawals = await apiRequest(`/withdrawals/user/${DEFAULT_USER_ID}`);
      return withdrawals;
    } catch (error) {
      console.error('Error fetching withdrawals:', error);
      throw error;
    }
  },
  
  /**
   * Create a new withdrawal request
   * @param {object} withdrawal - Withdrawal details
   * @returns {Promise} Created withdrawal
   */
  requestWithdrawal: async (withdrawal) => {
    try {
      const newWithdrawal = {
        ...withdrawal,
        userId: DEFAULT_USER_ID,
        status: 'PENDING'
      };
      
      const response = await apiRequest('/withdrawals', {
        method: 'POST',
        body: JSON.stringify(newWithdrawal)
      });
      
      return response;
    } catch (error) {
      console.error('Error requesting withdrawal:', error);
      throw error;
    }
  },
  
  /**
   * Add a new investment
   * @param {object} investment - Investment details
   * @returns {Promise} Created investment
   */
  addInvestment: async (investment) => {
    try {
      const newInvestment = {
        ...investment,
        userId: DEFAULT_USER_ID
      };
      
      const response = await apiRequest('/investments', {
        method: 'POST',
        body: JSON.stringify(newInvestment)
      });
      
      return response;
    } catch (error) {
      console.error('Error adding investment:', error);
      throw error;
    }
  },
};

export default API;